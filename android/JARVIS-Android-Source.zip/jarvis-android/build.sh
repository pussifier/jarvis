#!/usr/bin/env bash
set -euo pipefail
PROJECT_DIR="$(cd -- "$(dirname -- "$0")" && pwd)"
TOOLS_DIR="${JARVIS_ANDROID_TOOLS:-$(dirname "$PROJECT_DIR")/android-tools}"
JDK_DIR="${JARVIS_JDK:-$TOOLS_DIR/jdk/jdk-21.0.2}"
BUILD_TOOLS_DIR="${JARVIS_BUILD_TOOLS:-$TOOLS_DIR/buildtools/android-15}"
ANDROID_JAR="${JARVIS_ANDROID_JAR:-$TOOLS_DIR/platform/android-35/android.jar}"
cd "$PROJECT_DIR"
for required in "$JDK_DIR/bin/javac" "$BUILD_TOOLS_DIR/aapt2" "$BUILD_TOOLS_DIR/zipalign" "$ANDROID_JAR" "$BUILD_TOOLS_DIR/lib/d8.jar" "$BUILD_TOOLS_DIR/lib/apksigner.jar"; do
  if [[ ! -f "$required" ]]; then echo "Missing build tool: $required" >&2; exit 1; fi
done
mkdir -p build/classes build/generated build/dex
python3 - <<'PY'
from pathlib import Path
import zipfile, shutil
root=Path.cwd()
for name in ['classes','generated','dex']:
    p=root/'build'/name
    if p.is_symlink():raise RuntimeError('Generated build directories must not be symlinks')
    shutil.rmtree(p)
    p.mkdir()
shutil.copyfile(root/'THIRD_PARTY_NOTICES.md',root/'assets/THIRD_PARTY_NOTICES.md')
with zipfile.ZipFile(root/'assets/source.zip','w',zipfile.ZIP_DEFLATED) as z:
    allowed=['AndroidManifest.xml','src','res','assets','tests','build.sh','README.md','THIRD_PARTY_NOTICES.md','.gitignore']
    for name in allowed:
        base=root/name
        for p in (base.rglob('*') if base.is_dir() else [base]):
            if p.is_file() and not p.is_symlink() and p.name!='source.zip' and '__pycache__' not in p.parts:
                z.write(p,'jarvis-android/'+p.relative_to(root).as_posix())
print('Complete native source archive prepared; no signing keys or runtime data included.')
PY
"$BUILD_TOOLS_DIR/aapt2" compile --dir res -o build/resources.zip
"$BUILD_TOOLS_DIR/aapt2" link -I "$ANDROID_JAR" --manifest AndroidManifest.xml --java build/generated -A assets -o build/resources.apk build/resources.zip
find src build/generated -name '*.java' -print | sort > build/sources.list
"$JDK_DIR/bin/javac" -encoding UTF-8 --release 8 -Xlint:-options -classpath "$ANDROID_JAR" -d build/classes @build/sources.list
"$JDK_DIR/bin/jar" --create --file build/classes.jar -C build/classes .
"$JDK_DIR/bin/java" -cp "$BUILD_TOOLS_DIR/lib/d8.jar" com.android.tools.r8.D8 --lib "$ANDROID_JAR" --min-api 26 --output build/dex build/classes.jar
python3 - <<'PY'
import shutil,zipfile
from pathlib import Path
shutil.copyfile('build/resources.apk','build/unsigned.apk')
with zipfile.ZipFile('build/unsigned.apk','a',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(Path('build/dex').glob('*.dex')):z.write(p,p.name)
PY
"$BUILD_TOOLS_DIR/zipalign" -f -p 4 build/unsigned.apk build/aligned.apk
SIGN_DIR="$TOOLS_DIR/private-signing"
mkdir -p "$SIGN_DIR"
chmod 700 "$SIGN_DIR"
if [[ ! -f "$SIGN_DIR/jarvis-local-test.p12" ]]; then
  python3 - "$SIGN_DIR/store.pass" <<'PY'
import os,secrets,sys
from pathlib import Path
p=Path(sys.argv[1]);p.write_text(secrets.token_urlsafe(36));os.chmod(p,0o600)
PY
  "$JDK_DIR/bin/keytool" -genkeypair -alias jarvis-local-test -keyalg RSA -keysize 3072 -validity 3650 -dname 'CN=JARVIS Local Test Build' -storetype PKCS12 -keystore "$SIGN_DIR/jarvis-local-test.p12" -storepass:file "$SIGN_DIR/store.pass" -keypass:file "$SIGN_DIR/store.pass"
  chmod 600 "$SIGN_DIR/jarvis-local-test.p12"
fi
"$JDK_DIR/bin/java" -jar "$BUILD_TOOLS_DIR/lib/apksigner.jar" sign --ks "$SIGN_DIR/jarvis-local-test.p12" --ks-key-alias jarvis-local-test --ks-pass "file:$SIGN_DIR/store.pass" --out build/JARVIS-S24-Ultra.apk build/aligned.apk
"$JDK_DIR/bin/java" -jar "$BUILD_TOOLS_DIR/lib/apksigner.jar" verify --verbose --print-certs build/JARVIS-S24-Ultra.apk
"$BUILD_TOOLS_DIR/zipalign" -c -p 4 build/JARVIS-S24-Ultra.apk
python3 - <<'PY'
import hashlib
from pathlib import Path
p=Path('build/JARVIS-S24-Ultra.apk')
print('APK:',p.resolve())
print('Bytes:',p.stat().st_size)
print('SHA256:',hashlib.sha256(p.read_bytes()).hexdigest())
PY
