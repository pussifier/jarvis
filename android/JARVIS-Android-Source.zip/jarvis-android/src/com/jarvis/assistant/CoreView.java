package com.jarvis.assistant;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.*;
import android.view.View;

/** Native Android Canvas visualizer. It reflects state, not invented audio measurements. */
public final class CoreView extends View {
    private final Paint paint=new Paint(3);private String state="idle";private long epoch=System.currentTimeMillis();
    public CoreView(Context context){super(context);setContentDescription("JARVIS core: standing by");}
    public void state(String value){state=value;setContentDescription("JARVIS core: "+value);invalidate();}
    private int color(){return state.equals("listening")?Color.rgb(147,195,255):state.equals("thinking")?Color.rgb(224,197,127):Color.rgb(131,224,207);}
    @Override protected void onDraw(Canvas canvas){
        super.onDraw(canvas);float x=getWidth()/2f,y=getHeight()/2f,r=Math.min(getWidth(),getHeight())*.31f;
        boolean animate=ValueAnimator.areAnimatorsEnabled()&&getWindowVisibility()==VISIBLE&&isShown();
        float t=animate?(System.currentTimeMillis()-epoch)/1000f:0;
        paint.setShader(new RadialGradient(x,y,r*1.8f,new int[]{Color.argb(30,110,220,198),Color.TRANSPARENT},null,Shader.TileMode.CLAMP));paint.setStyle(Paint.Style.FILL);canvas.drawCircle(x,y,r*1.8f,paint);paint.setShader(null);
        paint.setStrokeWidth(1.5f*getResources().getDisplayMetrics().density);paint.setStyle(Paint.Style.STROKE);paint.setColor(Color.rgb(42,78,83));canvas.drawCircle(x,y,r*1.38f,paint);canvas.drawCircle(x,y,r*1.15f,paint);
        paint.setColor(color());paint.setAlpha(210);canvas.drawCircle(x,y,r,paint);paint.setAlpha(90);canvas.drawCircle(x,y,r*.87f,paint);
        paint.setAlpha(150);RectF oval=new RectF(x-r*1.24f,y-r*1.24f,x+r*1.24f,y+r*1.24f);canvas.drawArc(oval,t*(state.equals("thinking")?65:8),state.equals("thinking")?78:145,false,paint);
        paint.setAlpha(90);for(int i=0;i<48;i++){double a=i*Math.PI/24;float inner=r*(i%4==0?1.43f:1.48f),outer=r*1.53f;canvas.drawLine(x+(float)Math.cos(a)*inner,y+(float)Math.sin(a)*inner,x+(float)Math.cos(a)*outer,y+(float)Math.sin(a)*outer,paint);}
        paint.setStyle(Paint.Style.FILL);paint.setColor(Color.rgb(216,255,245));paint.setAlpha(255);paint.setTextAlign(Paint.Align.CENTER);paint.setTypeface(Typeface.create("sans-serif-light",Typeface.NORMAL));paint.setTextSize(r*.79f);canvas.drawText("J",x,y+r*.22f,paint);
        if(state.equals("speaking")){paint.setColor(color());paint.setStyle(Paint.Style.STROKE);paint.setAlpha((int)(60+40*Math.sin(t*4)));canvas.drawCircle(x,y,r*(1.08f+.035f*(float)Math.sin(t*4)),paint);}
        paint.setStyle(Paint.Style.FILL);paint.setAlpha(255);paint.setTextSize(r*.12f);paint.setTypeface(Typeface.MONOSPACE);paint.setColor(Color.rgb(117,164,164));canvas.drawText("NATIVE CORE / "+state.toUpperCase(),x,y+r*1.88f,paint);
        if(animate)postInvalidateDelayed(33);
    }
}
