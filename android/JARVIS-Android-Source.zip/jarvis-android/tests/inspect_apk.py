"""Inspect the actual signed APK; this is not a device runtime test."""
import hashlib
import io
import os
from pathlib import Path
import re
import subprocess
import zipfile

project = Path(__file__).resolve().parents[1]
tools = Path(os.environ.get('JARVIS_ANDROID_TOOLS', project.parent / 'android-tools'))
build_tools = Path(os.environ.get('JARVIS_BUILD_TOOLS', tools / 'buildtools/android-15'))
jdk = Path(os.environ.get('JARVIS_JDK', tools / 'jdk/jdk-21.0.2'))
apk = project / 'build/JARVIS-S24-Ultra.apk'

def command(*args):
    return subprocess.run([str(a) for a in args], check=True, capture_output=True, text=True).stdout

badging = command(build_tools / 'aapt2', 'dump', 'badging', apk)
manifest = command(build_tools / 'aapt2', 'dump', 'xmltree', apk, '--file', 'AndroidManifest.xml')
assert "name='com.jarvis.assistant'" in badging
assert "launchable-activity: name='com.jarvis.assistant.MainActivity'" in badging
assert "minSdkVersion:'26'" in badging and "targetSdkVersion:'35'" in badging
permissions = re.findall(r"uses-permission: name='([^']+)'", badging)
assert set(permissions) == {'android.permission.INTERNET', 'android.permission.RECORD_AUDIO'}
for attribute in ('debuggable', 'allowBackup', 'fullBackupContent', 'usesCleartextTraffic'):
    assert re.search(r':' + attribute + r'\([^)]*\)=false', manifest), attribute
signature = command(jdk / 'bin/java', '-jar', build_tools / 'lib/apksigner.jar', 'verify', '--verbose', apk)
assert 'Verified using v2 scheme (APK Signature Scheme v2): true' in signature
assert 'Verified using v3 scheme (APK Signature Scheme v3): true' in signature
command(build_tools / 'zipalign', '-c', '-p', '4', apk)
with zipfile.ZipFile(apk) as archive:
    assert archive.testzip() is None
    names = archive.namelist()
    assert 'classes.dex' in names and 'AndroidManifest.xml' in names
    assert b'Lcom/jarvis/assistant/MainActivity;' in archive.read('classes.dex')
    assert b'Landroid/webkit/WebView;' not in archive.read('classes.dex')
    assert not any(n.endswith(('.html', '.js', '.py', '.p12', '.pass', '.jks')) for n in names)
    rules = archive.read('assets/rules.md')
    assert rules == (project / 'assets/rules.md').read_bytes()
    assert len(re.findall(rb'^\d+\. \*\*', rules, re.MULTILINE)) == 12
    with zipfile.ZipFile(io.BytesIO(archive.read('assets/source.zip'))) as source:
        assert source.testzip() is None
        assert source.read('jarvis-android/src/com/jarvis/assistant/MainActivity.java') == (project / 'src/com/jarvis/assistant/MainActivity.java').read_bytes()
        assert source.read('jarvis-android/assets/rules.md') == rules
        assert source.read('jarvis-android/README.md') == (project / 'README.md').read_bytes()
        assert not any('/build/' in n or '/private-signing/' in n or n.endswith(('.p12', '.pass', '.jks', '.keystore')) for n in source.namelist())
        print('Source ZIP integrity and exclusions verified:', len(source.namelist()), 'entries')
print('Native package, launcher, permissions, privacy flags, 12 rules, DEX and source verified.')
print('APK v2/v3 signatures and alignment verified.')
print('APK bytes:', apk.stat().st_size)
print('APK SHA256:', hashlib.sha256(apk.read_bytes()).hexdigest())
print('No physical device, Android UI runtime, microphone, Keystore runtime, TTS or live API test is implied.')
