# JARVIS for Galaxy S24 Ultra

A real native Android app, with its own launcher icon and an installable APK. The interface, Markdown memory, session history, action review, visualizer and touch/stylus board run on the phone. It has no WebView, desktop Python server, localhost URL, or browser installation requirement. The APK targets Android API 35 and declares Android 8.0/API 26 as its minimum; actual S24 Ultra device behavior must be verified on the device.

## Install and connect

Install the signed `JARVIS-S24-Ultra.apk` from the supplied transfer location. On your phone, open the APK using My Files or your download app and follow Android’s installation prompts. Samsung’s Auto Blocker, unknown-app installation permissions, organizational policies and Android developer verification may affect sideloading; follow the phone’s own prompts and current Samsung/Android guidance. No Play Store listing or remote phone installation has been performed.

Open JARVIS, select **Settings**, and enter your personal OpenAI API key **on your phone**. Tap **Save key**, return to Chat and send a short message. A successful response verifies that account/model access for that session. A ChatGPT subscription or ChatGPT app connection does not automatically give this app an API key.

The app encrypts the user-entered key with an Android Keystore key and stores only ciphertext/IV in private preferences. The credential is decrypted in the app process to authenticate direct HTTPS requests. There is no shared key in the APK, source ZIP, notes, docs or build script. Do not put a key in chat or memory notes. Use **Remove key** to remove the stored credential. Settings blocks screenshots; automatic app backups/device transfer are disabled by the manifest and extraction rules. The app process can access its own decrypted credential; this is personal-use key storage, not a server-held shared credential service.

Defaults are `gpt-6.1-sol` for chat and `gpt-transcribe` for file transcription. Both names can be changed in Settings; account availability is checked through use rather than invented. Chat and transcription use your API credits. They require internet access. Notes, reference reading and the touch board work offline.

## Use JARVIS

- **Chat:** text entry, saved conversations, history and new conversation controls. The model can search/read full notes and propose a note update or a board card. Pending effects require an exact native review decision. Reject is final; stale-note revisions are rejected and completed effects cannot replay. Interrupted effects are marked for inspection rather than retried automatically. There are no shell, browser, email, phone-control, deployment, or app-install tools.
- **Voice input:** allow the microphone when requested, then hold **Talk**. Release to send that completed recording to OpenAI for transcription. Review the transcript, then tap **Send**. Backgrounding the app stops/discards active recording. Temporary recordings are deleted after transcription/cancellation or next startup following a process death. No wake-word or always-listening background service is included.
- **Voice output:** enable **Speak · AI voice**. Android’s installed TTS engine reads the reply. Availability, supported languages, and network processing depend on that engine. Stop interrupts speech or the current network request; a provider request may already have incurred usage. All spoken output is AI-generated.
- **Memory:** create/edit/search Markdown notes, pin a complete note to a chat request, import a note through Android’s document picker, and export an Obsidian-compatible vault ZIP. Rules, generated indexes and append-only daily logs are protected from replacement in the app. App-private memory and chat history are removed on uninstall; export notes you want to keep. Exports contain your notes/rules, so share them deliberately.
- **Your rules:** all twelve supplied rules seed `Rules.md` on first launch; it is reloaded fresh each turn. Existing rules are kept. No credentials belong in it. Daily notes use the actual device clock converted to Asia/Manila. Notes are the knowledge source of truth; full chat transcripts are stored separately.
- **Board:** native touch/S Pen-friendly note cards. Drag cards, pinch a held card to scale, drag empty space to pan, and tap to read. Approved text-card proposals also appear. The accessible Memory list provides the same note access. This board replaces the desktop webcam/hand-tracking board; no camera permission is requested.
- **Core:** a native Canvas visualizer mirrors idle/listening/thinking/speaking state and respects disabled system animations. It does not pretend to measure Android TTS audio waveforms.
- **Library:** two full credited marketing reference notes. Marketing context sends both full notes with the next request. Imported/saved reference documents are data and cannot authorize actions.
- **Source:** Settings → Export complete source saves the full native source archive through Android’s document picker, including notices/license texts. No runtime notes, sessions or signing keys are included.

Selected notes, enabled marketing references, action records, and full conversation history are sent to OpenAI as request context. Responses use `store: false`; that is not a claim of zero provider retention. Complete-read and full-history limits return explicit errors instead of silently claiming a partial read is complete. Credential-like strings are rejected from memory-write proposals/edits.

## Build from source

The source builds with official Android command-line build tools and OpenJDK, without Gradle or a third-party runtime dependency:

```sh
bash build.sh
```

The default workspace tool layout is a sibling `android-tools/` directory, containing `jdk/jdk-21.0.2`, `buildtools/android-15` (35.0.0), and `platform/android-35/android.jar`. Override using `JARVIS_ANDROID_TOOLS`, `JARVIS_JDK`, `JARVIS_BUILD_TOOLS` and `JARVIS_ANDROID_JAR` as needed. The build compiles native Java/resources, creates DEX, packages assets, aligns and signs the APK, verifies its signature/alignment, and prints its SHA256.

The local test signing keystore is stored separately in the workspace build-tools `private-signing` directory. Its password is read from a private file, never a command-line value or a document. Preserve that keystore securely if you need future APK updates to install over this version. The APK is signed for sideload testing, not a Play production release. Signing files and credentials are excluded from the source archive.

## Validation limits

The native core test suite passed 25 tests against temporary storage and a local mock OpenAI service. The Android APK compiled successfully; APK v2/v3 signatures and alignment verified. Package inspection confirmed the native launcher activity and declared permissions, and checked the source archive for integrity and exclusion of runtime/signing data. These are build/core checks, not an on-device launch test.

Repeat the checks with:

```sh
bash tests/run.sh
bash build.sh
python3 tests/inspect_apk.py
```

The JVM tests require the test-only `org.json:json:20240303` JAR at the workspace tools path `json-tests.jar`, or set `JARVIS_TEST_JSON` to a local copy. The Android app itself uses platform JSON APIs and does not include that test dependency. Native core tests use temporary folders and a local mock OpenAI service; they do not spend API credits. The build checks APK structure, native activity/permissions, signing and alignment. No physical S24 Ultra is connected to this workspace, and no API credential is configured here. An APK build/signature check does not establish live chat, on-device Android Keystore, microphone, TTS, touch/stylus, lifecycle, or rendered-device behavior. Those require testing after installation.

## License

Native application source is AGPL-3.0-or-later, without warranty; complete text is bundled in `assets/licenses/AGPL-3.0.txt`. Marketing notes retain CC BY-SA 4.0 and Jared Rhodenizer’s attribution. See `THIRD_PARTY_NOTICES.md`. This independent app is not endorsed by OpenAI, Samsung or Jared Rhodenizer.
