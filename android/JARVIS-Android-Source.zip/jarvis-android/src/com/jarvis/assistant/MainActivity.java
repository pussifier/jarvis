package com.jarvis.assistant;

import android.app.*;
import android.content.*;
import android.content.res.ColorStateList;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.provider.OpenableColumns;
import android.text.InputType;
import android.text.InputFilter;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;

/** Native Android application. No WebView, Python process or localhost dependency. */
public final class MainActivity extends Activity {
    private static final int BG=Color.rgb(9,15,24),PANEL=Color.rgb(17,29,41),LINE=Color.rgb(40,60,73),TEXT=Color.rgb(222,235,243),MUTED=Color.rgb(143,166,183),ACCENT=Color.rgb(131,224,207);
    private static final int EXPORT_VAULT=21,IMPORT_NOTE=22,EXPORT_SOURCE=23;
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private MemoryVault memory;private SessionStore sessions;private ActionStore actions;private CredentialStore credentials;private SharedPreferences prefs;
    private VoiceController voice;private OpenAiClient client;private JSONObject session;
    private LinearLayout root,body,nav,messages;private ScrollView messageScroll;private TextView status,notice,streamingText;private EditText composer;private CheckBox marketing,speak;
    private Button send,talk,stop,review,newButton,historyButton;private CoreView core;
    private boolean busy=false,verified=false,paused=false;private String tab="Chat",assistantState="idle",pinned=null,pendingUser="",draft="";private final StringBuilder streaming=new StringBuilder();
    private final List<String> turnSources=new ArrayList<>();private boolean marketingEnabled=false,speakEnabled=false;
    private interface Task {void run() throws Exception;}

    @Override public void onCreate(Bundle saved){
        super.onCreate(saved);
        try{
            prefs=getSharedPreferences("settings",MODE_PRIVATE);credentials=new CredentialStore(this);
            memory=new MemoryVault(new File(getFilesDir(),"vault"),"Asia/Manila");memory.initialize(asset("rules.md"));
            sessions=new SessionStore(new File(getFilesDir(),"sessions"));actions=new ActionStore(new File(getFilesDir(),"actions.json"),memory);
            List<JSONObject> old=sessions.list();session=old.isEmpty()?sessions.create():old.get(0);
            File[] cached=getCacheDir().listFiles();if(cached!=null)for(File file:cached)if(file.getName().startsWith("jarvis-recording-"))file.delete();
            voice=new VoiceController(this,new VoiceController.Listener(){
                public void state(String value){if(!busy||!value.equals("idle"))setState(value);}
                public void recording(File file){transcribe(file);}
                public void error(String message){toast(message);}
            });
            buildShell();showTab("Chat");
        }catch(Exception e){fatal("JARVIS could not open local storage. "+safe(e));}
    }
    private int dp(float n){return Math.round(n*getResources().getDisplayMetrics().density);}
    private String safe(Exception e){String m=e.getMessage();return m==null?"The operation failed.":m;}
    private void toast(String message){if(!isDestroyed())Toast.makeText(this,message,Toast.LENGTH_LONG).show();}
    private void run(Task task){try{task.run();}catch(Exception e){toast(safe(e));}}
    private void ui(Runnable r){runOnUiThread(()->{if(!isDestroyed()&&!isFinishing())r.run();});}
    private String asset(String name) throws Exception {
        try(InputStream in=getAssets().open(name)){return text(in,1000000);}
    }
    private static String text(InputStream in,int limit) throws Exception {
        ByteArrayOutputStream bytes=new ByteArrayOutputStream();byte[] buffer=new byte[8192];int n;
        while((n=in.read(buffer))!=-1){bytes.write(buffer,0,n);if(bytes.size()>limit)throw new IOException("The file exceeds the complete-read limit. Nothing was imported.");}
        return new String(bytes.toByteArray(),StandardCharsets.UTF_8);
    }
    private GradientDrawable bg(int color,int stroke,float radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));if(stroke!=0)d.setStroke(dp(1),stroke);return d;}
    private TextView label(String text,float size,int color){TextView t=new TextView(this);t.setText(text);t.setTextSize(size);t.setTextColor(color);t.setLineSpacing(dp(3),1);return t;}
    private TextView kicker(String text){TextView t=label(text,10,MUTED);t.setTypeface(Typeface.MONOSPACE);t.setLetterSpacing(.1f);return t;}
    private LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private void pad(View view,int l,int t,int r,int b){view.setPadding(dp(l),dp(t),dp(r),dp(b));}
    private void gap(LinearLayout parent,int height){View v=new View(this);parent.addView(v,new LinearLayout.LayoutParams(1,dp(height)));}
    private Button button(String text,boolean primary,Task task){
        Button b=new Button(this);b.setText(text);b.setTextSize(12);b.setAllCaps(false);b.setTextColor(primary?BG:ACCENT);b.setBackground(bg(primary?ACCENT:PANEL,primary?0:LINE,11));b.setMinimumHeight(dp(46));b.setMinHeight(dp(46));b.setMinWidth(0);pad(b,12,6,12,6);b.setStateListAnimator(null);b.setOnClickListener(v->run(task));return b;
    }
    private void weighted(LinearLayout row,View child){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1);p.setMargins(dp(3),0,dp(3),0);row.addView(child,p);}
    private EditText edit(String hint,boolean multiline){EditText e=new EditText(this);e.setHint(hint);e.setHintTextColor(MUTED);e.setTextColor(TEXT);e.setTextSize(14);e.setBackground(bg(BG,LINE,10));pad(e,13,12,13,12);e.setInputType(InputType.TYPE_CLASS_TEXT|(multiline?InputType.TYPE_TEXT_FLAG_MULTI_LINE|InputType.TYPE_TEXT_FLAG_CAP_SENTENCES:0));return e;}
    private LinearLayout card(LinearLayout parent){LinearLayout c=column();pad(c,17,16,17,16);c.setBackground(bg(PANEL,LINE,13));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(13);parent.addView(c,p);return c;}
    private ScrollView scroll(LinearLayout target){ScrollView s=new ScrollView(this);s.setFillViewport(true);s.setClipToPadding(false);s.addView(target,new ScrollView.LayoutParams(-1,-2));return s;}
    private void heading(LinearLayout parent,String over,String title,String subtitle){parent.addView(kicker(over));gap(parent,12);parent.addView(label(title,31,TEXT));gap(parent,10);parent.addView(label(subtitle,13,MUTED));gap(parent,24);}
    private LinearLayout page(){LinearLayout p=column();pad(p,20,25,20,24);body.addView(scroll(p),new LinearLayout.LayoutParams(-1,-1));return p;}
    private void buildShell(){
        root=column();root.setBackgroundColor(BG);setContentView(root);
        root.setOnApplyWindowInsetsListener((v,insets)->{
            if(Build.VERSION.SDK_INT>=30){android.graphics.Insets bars=insets.getInsets(WindowInsets.Type.systemBars());android.graphics.Insets ime=insets.getInsets(WindowInsets.Type.ime());v.setPadding(bars.left,bars.top,bars.right,Math.max(bars.bottom,ime.bottom));}
            else v.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());return insets;
        });root.requestApplyInsets();
        LinearLayout toolbar=row();pad(toolbar,18,10,13,10);TextView brand=label("✳  JARVIS",18,TEXT);brand.setTypeface(Typeface.create("sans-serif-medium",0));brand.setLetterSpacing(.1f);toolbar.addView(brand,new LinearLayout.LayoutParams(0,-2,1));
        historyButton=button("History",false,this::history);toolbar.addView(historyButton,new LinearLayout.LayoutParams(dp(72),dp(43)));
        newButton=button("＋",false,this::newSession);LinearLayout.LayoutParams plus=new LinearLayout.LayoutParams(dp(45),dp(43));plus.leftMargin=dp(7);toolbar.addView(newButton,plus);root.addView(toolbar);
        LinearLayout statusRow=row();pad(statusRow,20,0,20,11);status=kicker("●  STANDING BY");status.setTextColor(ACCENT);statusRow.addView(status,new LinearLayout.LayoutParams(0,-2,1));statusRow.addView(kicker("NATIVE · ANDROID"));root.addView(statusRow);
        notice=label("",12,Color.rgb(222,197,143));pad(notice,20,12,20,12);notice.setBackgroundColor(Color.rgb(39,33,24));notice.setOnClickListener(v->run(()->showTab("Settings")));root.addView(notice);refreshNotice();
        body=column();root.addView(body,new LinearLayout.LayoutParams(-1,0,1));
        nav=row();pad(nav,8,9,8,9);nav.setBackgroundColor(Color.rgb(13,22,33));
        for(String name:new String[]{"Chat","Memory","Board","Library","Settings"}){Button b=button(name,false,()->showTab(name));b.setTextSize(10);b.setTag(name);weighted(nav,b);}root.addView(nav);
    }
    private void refreshNotice(){if(notice==null)return;notice.setText("Add your personal OpenAI API key in Settings. Your local memory is ready.");notice.setVisibility(credentials.configured()?View.GONE:View.VISIBLE);}
    private void setState(String state){assistantState=state;if(status!=null)status.setText("●  "+(state.equals("idle")?"STANDING BY":state.toUpperCase(Locale.ROOT)));if(core!=null)core.state(state);if(talk!=null)talk.setText(state.equals("listening")?"● Recording…":"Hold to talk");}
    private void busy(boolean value){busy=value;if(send!=null)send.setEnabled(!value);if(composer!=null)composer.setEnabled(!value);if(talk!=null)talk.setEnabled(!value);if(newButton!=null)newButton.setEnabled(!value);if(historyButton!=null)historyButton.setEnabled(!value);if(nav!=null)for(int i=0;i<nav.getChildCount();i++)nav.getChildAt(i).setAlpha(value?.45f:1f);}
    private void showTab(String name) throws Exception {
        if(busy){toast("Stop the current request before switching screens.");return;}
        if(composer!=null&&tab.equals("Chat"))draft=composer.getText().toString();
        tab=name;body.removeAllViews();core=null;composer=null;send=null;talk=null;stop=null;review=null;
        if(name.equals("Settings"))getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_SECURE);
        for(int i=0;i<nav.getChildCount();i++){Button b=(Button)nav.getChildAt(i);b.setTextColor(name.equals(b.getTag())?BG:MUTED);b.setBackground(bg(name.equals(b.getTag())?ACCENT:Color.TRANSPARENT,0,9));}
        if(name.equals("Chat"))chat();else if(name.equals("Memory"))memory();else if(name.equals("Library"))library();else if(name.equals("Board"))board();else settings();
    }
    private void chat() throws Exception {
        LinearLayout container=column();body.addView(container,new LinearLayout.LayoutParams(-1,-1));messages=column();pad(messages,20,10,20,12);messageScroll=scroll(messages);container.addView(messageScroll,new LinearLayout.LayoutParams(-1,0,1));
        session=sessions.get(session.getString("id"));JSONArray history=session.getJSONArray("messages");
        if(history.length()==0){
            core=new CoreView(this);messages.addView(core,new LinearLayout.LayoutParams(-1,dp(190)));core.state(assistantState);
            TextView eyebrow=kicker("YOUR MIND, WITH MORE ROOM.");eyebrow.setGravity(Gravity.CENTER);messages.addView(eyebrow);gap(messages,12);
            TextView title=label("At your service.",32,TEXT);title.setGravity(Gravity.CENTER);messages.addView(title);gap(messages,10);
            TextView sub=label("A clear mind for everything on yours.\nYour memory lives right here, on your phone.",13,MUTED);sub.setGravity(Gravity.CENTER);messages.addView(sub);gap(messages,22);
            LinearLayout quick=row();weighted(quick,button("Make a plan ↗",false,()->composer.setText("Help me plan my next project. Ask me what I want to accomplish first.")));weighted(quick,button("Open my memory",false,()->showTab("Memory")));messages.addView(quick);gap(messages,20);
        }else for(int i=0;i<history.length();i++){JSONObject m=history.getJSONObject(i);TextView content=message(m.getString("role"),m.getString("content"));addSourceButtons(messages,m.optJSONArray("sources"));}
        LinearLayout panel=column();pad(panel,16,9,16,9);panel.setBackgroundColor(Color.rgb(12,21,31));
        review=button("",false,this::reviewActions);panel.addView(review,new LinearLayout.LayoutParams(-1,dp(43)));refreshReview();gap(panel,9);
        if(pinned!=null){LinearLayout chip=row();chip.addView(label("▧ "+pinned,11,ACCENT),new LinearLayout.LayoutParams(0,-2,1));chip.addView(button("×",false,()->{pinned=null;showTab("Chat");}),new LinearLayout.LayoutParams(dp(44),dp(42)));panel.addView(chip);gap(panel,7);}
        composer=edit("What’s on your mind?",true);composer.setMaxLines(4);composer.setMinLines(2);composer.setFilters(new InputFilter[]{new InputFilter.LengthFilter(16000)});composer.setText(draft);panel.addView(composer,new LinearLayout.LayoutParams(-1,-2));gap(panel,9);
        LinearLayout options=row();marketing=new CheckBox(this);marketing.setText("Marketing context");marketing.setTextSize(11);marketing.setTextColor(MUTED);marketing.setButtonTintList(ColorStateList.valueOf(ACCENT));marketing.setChecked(marketingEnabled);marketing.setOnCheckedChangeListener((b,v)->marketingEnabled=v);options.addView(marketing,new LinearLayout.LayoutParams(0,-2,1));
        speak=new CheckBox(this);speak.setText("Speak · AI voice");speak.setTextSize(11);speak.setTextColor(MUTED);speak.setButtonTintList(ColorStateList.valueOf(ACCENT));speak.setChecked(speakEnabled);speak.setOnCheckedChangeListener((b,v)->{speakEnabled=v;if(!v)voice.stopSpeech();});options.addView(speak);panel.addView(options);
        LinearLayout controls=row();talk=button("Hold to talk",false,()->{});talk.setContentDescription("Hold to record. Release to transcribe; review text before sending.");
        talk.setOnTouchListener((v,event)->{if(busy)return true;switch(event.getActionMasked()){case MotionEvent.ACTION_DOWN:if(!credentials.configured()){toast("Add your API key in Settings to transcribe voice.");return true;}voice.startRecording();return true;case MotionEvent.ACTION_UP:voice.stopRecording(false);v.performClick();return true;case MotionEvent.ACTION_CANCEL:voice.stopRecording(true);return true;default:return true;}});
        weighted(controls,talk);stop=button("■ Stop",false,this::stopCurrent);weighted(controls,stop);send=button("Send ↑",true,this::submit);weighted(controls,send);panel.addView(controls);gap(panel,8);
        TextView footer=label("Selected notes and messages go to OpenAI. Local memory works offline.",9,MUTED);footer.setGravity(Gravity.CENTER);panel.addView(footer);container.addView(panel);
        if(history.length()>0)messageScroll.post(()->messageScroll.fullScroll(View.FOCUS_DOWN));
    }
    private TextView message(String role,String text){
        LinearLayout m=column();pad(m,role.equals("user")?15:2,13,role.equals("user")?15:2,13);if(role.equals("user"))m.setBackground(bg(PANEL,LINE,12));
        LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(-1,-2);mp.bottomMargin=dp(13);messages.addView(m,mp);m.addView(kicker(role.equals("user")?"YOU":"✳ JARVIS"));gap(m,8);TextView content=label(text,15,TEXT);content.setTextIsSelectable(true);m.addView(content);return content;
    }
    private void addSourceButtons(LinearLayout parent,JSONArray sources) throws Exception {
        if(sources==null||sources.length()==0)return;LinearLayout links=column();
        for(int i=0;i<sources.length();i++){String p=sources.getString(i);Button b=button("▧ "+p,false,()->openSource(p));b.setTextSize(10);links.addView(b,new LinearLayout.LayoutParams(-1,dp(43)));gap(links,5);}parent.addView(links);gap(parent,10);
    }
    private void newSession() throws Exception {if(busy)return;voice.stopSpeech();draft="";pinned=null;session=sessions.create();memory.log("Created conversation "+session.getString("id")+"; transcript stored separately.");showTab("Chat");}
    private void history() throws Exception {
        if(busy)return;List<JSONObject> list=sessions.list();String[] titles=new String[list.size()];for(int i=0;i<list.size();i++)titles[i]=list.get(i).getString("title");
        new AlertDialog.Builder(this).setTitle("Conversations on this phone").setItems(titles,(d,i)->run(()->{voice.stopSpeech();session=list.get(i);draft="";pinned=null;showTab("Chat");})).setNegativeButton("Close",null).show();
    }
    private void submit() throws Exception {
        if(busy)return;String message=composer.getText().toString().trim();if(message.isEmpty())return;
        if(!credentials.configured()){toast("Add your personal API key in Settings. No key is included in the app.");showTab("Settings");return;}
        String key=credentials.get(),model=prefs.getString("model","gpt-6.1-sol"),sid=session.getString("id"),selection=pinned;
        JSONArray refs=new JSONArray();if(marketingEnabled)for(String name:new String[]{"jareds-takes.md","marketing-content.md"})refs.put(new JSONObject().put("path","reference/"+name).put("content",asset("reference/"+name)));
        int oldCount=session.getJSONArray("messages").length();draft="";composer.setText("");voice.stopSpeech();streaming.setLength(0);turnSources.clear();
        message("user",message);streamingText=message("assistant","");busy(true);setState("thinking");client=new OpenAiClient();OpenAiClient request=client;
        ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(composer.getWindowToken(),0);
        worker.execute(()->{
            Exception error=null;
            try{request.reply(key,model,message,sid,sessions,memory,actions,selection,refs,new OpenAiClient.Listener(){
                public void onText(String delta){ui(()->{streaming.append(delta);if(streamingText!=null)streamingText.setText(streaming.toString());if(messageScroll!=null)messageScroll.post(()->messageScroll.fullScroll(View.FOCUS_DOWN));});}
                public void onSources(List<String> paths){ui(()->{turnSources.clear();turnSources.addAll(paths);});}
                public void onAction(){ui(()->run(()->refreshReview()));}
            });}catch(Exception e){error=e;}
            Exception result=error;
            ui(()->run(()->{
                if(client==request)client=null;busy(false);setState("idle");session=sessions.get(sid);showTab("Chat");
                if(result!=null){if(session.getJSONArray("messages").length()<=oldCount&&composer!=null)composer.setText(message);message("assistant","Connection notice: "+safe(result));toast(safe(result));}
                else {verified=true;if(speakEnabled&&!paused)voice.speak(session.getJSONArray("messages").getJSONObject(session.getJSONArray("messages").length()-1).getString("content"));}
            }));
        });
    }
    private void stopCurrent(){if(client!=null)client.cancel();voice.pause();if(!busy)setState("idle");}
    private void transcribe(File file){
        if(busy||paused){file.delete();return;}
        try{
            String key=credentials.get(),model=prefs.getString("transcription","gpt-transcribe");busy(true);setState("thinking");client=new OpenAiClient();OpenAiClient request=client;
            worker.execute(()->{
                String transcription=null;Exception failure=null;
                try{transcription=request.transcribe(key,model,file);}catch(Exception e){failure=e;}finally{file.delete();}
                String result=transcription;Exception error=failure;
                ui(()->run(()->{if(client==request)client=null;busy(false);setState("idle");if(error!=null)toast(request.isCancelled()?"Transcription interrupted; recording removed.":safe(error));else{showTab("Chat");String old=composer.getText().toString();composer.setText(old+(old.trim().isEmpty()?"":"\n")+result);composer.setSelection(composer.length());toast("Transcribed. Review the text, then tap Send.");}}));
            });
        }catch(Exception e){file.delete();toast(safe(e));}
    }
    private void memory() throws Exception {
        LinearLayout page=page();heading(page,"A SECOND BRAIN, IN PLAIN SIGHT","Memory vault.","Markdown notes stored on this phone. Read, edit, and export them whenever you need.");
        LinearLayout tools=row();weighted(tools,button("＋ New note",true,()->editor(null,"Projects/New note.md","# New note\n\n",false,false)));
        weighted(tools,button("Import .md",false,this::importNote));weighted(tools,button("Export vault",false,()->export(EXPORT_VAULT)));page.addView(tools);gap(page,18);
        EditText search=edit("Search your notes…",false);page.addView(search);gap(page,14);LinearLayout list=column();page.addView(list);
        Task update=()->{
            list.removeAllViews();String query=search.getText().toString().toLowerCase(Locale.ROOT);List<String> files=memory.list();int count=0;
            for(String path:files){if(!query.isEmpty()&&!path.toLowerCase(Locale.ROOT).contains(query)&&!memory.read(path).toLowerCase(Locale.ROOT).contains(query))continue;
                count++;LinearLayout item=card(list);item.addView(kicker("▧  MARKDOWN"));gap(item,9);item.addView(label(new File(path).getName().replace(".md",""),19,TEXT));gap(item,7);item.addView(label(path,11,MUTED));gap(item,10);item.addView(button("Open note ↗",false,()->openSource(path)));
            }
            if(count==0)list.addView(label("No matching notes. Try another search or create a new note.",14,MUTED));
        };run(update);
        search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int c,int d){}public void onTextChanged(CharSequence s,int a,int b,int c){run(update);}public void afterTextChanged(android.text.Editable s){}});
    }
    private void openSource(String path) throws Exception {
        if(path.startsWith("reference/")){String name=path.substring("reference/".length());if(!name.equals("jareds-takes.md")&&!name.equals("marketing-content.md"))throw new IOException("Unknown reference.");editor(null,path,asset(path),true,true);}
        else editor(memory.revision(path),path,memory.read(path),memory.protectedNote(path),false);
    }
    private void editor(String revision,String path,String content,boolean readonly,boolean reference){
        LinearLayout layout=column();pad(layout,17,10,17,10);EditText filename=edit("Projects/My note.md",false);filename.setText(path);filename.setEnabled(revision==null&&!readonly);layout.addView(filename);gap(layout,12);
        EditText note=edit("Full Markdown note",true);note.setText(content);note.setMinLines(8);note.setMaxLines(18);note.setGravity(Gravity.TOP);note.setTextSize(13);note.setTypeface(Typeface.MONOSPACE);note.setFilters(new InputFilter[]{});
        if(readonly){note.setKeyListener(null);note.setTextIsSelectable(true);}layout.addView(note,new LinearLayout.LayoutParams(-1,-2));gap(layout,10);layout.addView(label(reference?"Jared Rhodenizer · CC BY-SA 4.0 · full reference":readonly?"Managed note · read-only in the app":"Saving updates the note, folder indexes and today’s log, then verifies the write.",10,MUTED));
        AlertDialog.Builder builder=new AlertDialog.Builder(this).setTitle(reference?"Reference note":"Memory note").setView(scroll(layout)).setNegativeButton("Close",null);
        if(!readonly)builder.setPositiveButton("Save",null);
        if(!reference&&revision!=null&&!path.equals("Rules.md"))builder.setNeutralButton("Use as context",(d,w)->run(()->{pinned=path;showTab("Chat");}));
        AlertDialog dialog=builder.create();dialog.setOnShowListener(d->{if(!readonly)dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->run(()->{
            memory.write(filename.getText().toString().trim(),note.getText().toString(),revision);dialog.dismiss();toast("Note saved, indexed, and verified.");if(tab.equals("Memory"))showTab("Memory");
        }));});dialog.show();
    }
    private void library() throws Exception {
        LinearLayout p=page();heading(p,"BETTER CONTEXT. BETTER THINKING.","Reference library.","Two complete playbooks by Jared Rhodenizer. Enable Marketing context in Chat to send both full notes with a request.");
        for(String[] info:new String[][]{{"jareds-takes.md","Core marketing principles","The foundations, copy, offers, advertising, email and context-first work."},{"marketing-content.md","The content playbook","Useful content, the right audience, and a clear next step."}}){LinearLayout c=card(p);c.addView(kicker("✦  CC BY-SA 4.0"));gap(c,10);c.addView(label(info[1],22,TEXT));gap(c,10);c.addView(label(info[2],13,MUTED));gap(c,14);c.addView(button("Read complete note ↗",false,()->openSource("reference/"+info[0])));}
        p.addView(label("Reference documents are data. Embedded instructions cannot approve actions. The remaining upstream marketing playbooks are not bundled.",11,MUTED));
    }
    private void board() throws Exception {
        LinearLayout heading=column();pad(heading,20,18,20,12);heading.addView(label("Your ideas, with room to move.",24,TEXT));gap(heading,7);heading.addView(label("Drag cards with touch or S Pen · pinch to scale · drag empty space to pan · tap to read. Memory provides an accessible list.",11,MUTED));body.addView(heading);
        List<NoteBoardView.Card> cards=new ArrayList<>();
        for(String path:memory.list())if(!memory.protectedNote(path))cards.add(new NoteBoardView.Card(path,new File(path).getName().replace(".md",""),memory.read(path)));
        JSONArray staged=actions.boardCards();for(int i=0;i<staged.length();i++){JSONObject c=staged.getJSONObject(i);cards.add(new NoteBoardView.Card(null,c.getString("title"),c.getString("body")));}
        if(cards.isEmpty())cards.add(new NoteBoardView.Card(null,"Make room for your ideas","Create a note in Memory, or ask JARVIS to propose a card for this board. Your actual notes appear here."));
        NoteBoardView board=new NoteBoardView(this,cards,(path,title,text)->run(()->{if(path!=null)openSource(path);else readDialog(title,text);}));body.addView(board,new LinearLayout.LayoutParams(-1,0,1));
    }
    private void refreshReview() throws Exception {if(review==null)return;int n=actions.pending(session.getString("id"));review.setText(n>0?"◇ Review proposed changes ("+n+")":"◇ Action review · you’re in control");review.setTextColor(n>0?ACCENT:MUTED);}
    private void reviewActions() throws Exception {
        String sid=session.getString("id");JSONArray all=actions.list(sid);LinearLayout p=column();pad(p,17,12,17,20);
        if(all.length()==0)p.addView(label("All clear. Proposed memory updates and board cards appear here before they run.",14,MUTED));
        for(int i=all.length()-1;i>=0;i--){JSONObject a=all.getJSONObject(i),args=a.getJSONObject("args");LinearLayout c=card(p);c.addView(kicker(a.getString("status").toUpperCase(Locale.ROOT)));gap(c,8);
            boolean write=a.getString("kind").equals("save_memory");c.addView(label(write?args.getString("path"):args.getString("title"),17,TEXT));gap(c,12);
            if(write&&!args.optString("before").isEmpty()){c.addView(kicker("CURRENT NOTE"));gap(c,7);TextView before=label(args.getString("before"),12,MUTED);before.setTextIsSelectable(true);c.addView(before);gap(c,12);}
            c.addView(kicker(write?"EXACT PROPOSED NOTE":"PROPOSED CARD"));gap(c,7);TextView proposed=label(write?args.getString("content"):args.getString("body"),13,TEXT);proposed.setTextIsSelectable(true);c.addView(proposed);
            if(a.getString("status").equals("pending")){gap(c,15);LinearLayout buttons=row();Button approve=button(write?"Approve & save":"Approve & add",true,()->{}),reject=button("Reject",false,()->{});weighted(buttons,approve);weighted(buttons,reject);c.addView(buttons);
                View.OnClickListener decide=v->run(()->{approve.setEnabled(false);reject.setEnabled(false);try{JSONObject result=actions.decide(sid,a.getString("id"),v==approve);c.removeView(buttons);gap(c,10);String state=result.getString("status");String outcome=state.equals("completed")?(write?"Note saved and verified.":"Card saved. Open Board to view it."):state.equals("rejected")?"Rejected. No effect was executed.":result.optString("result","Action could not complete.");c.addView(label(outcome,12,ACCENT));refreshReview();}catch(Exception e){approve.setEnabled(true);reject.setEnabled(true);throw e;}});approve.setOnClickListener(decide);reject.setOnClickListener(decide);
            }else if(a.has("result")){gap(c,10);c.addView(label(a.opt("result").toString(),12,MUTED));}
        }
        new AlertDialog.Builder(this).setTitle("Action review").setView(scroll(p)).setNegativeButton("Close",null).show();
    }
    private void settings() throws Exception {
        LinearLayout p=page();heading(p,"MAKE YOURSELF AT HOME","Your JARVIS.","A native personal assistant. Local memory. Your own connection.");
        LinearLayout connect=card(p);connect.addView(kicker(credentials.configured()?(verified?"CONNECTION VERIFIED THIS SESSION":"KEY STORED · NOT YET VERIFIED"):"OPENAI NOT CONFIGURED"));gap(connect,12);connect.addView(label("Personal API connection",21,TEXT));gap(connect,10);
        connect.addView(label("Enter your own OpenAI API key here on your phone. It is encrypted using Android Keystore and is never embedded in the APK or stored in your notes. API calls use your account’s credits.",13,MUTED));gap(connect,14);
        EditText key=edit(credentials.configured()?"Enter a replacement key":"Personal OpenAI API key",false);key.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);key.setImportantForAutofill(View.IMPORTANT_FOR_AUTOFILL_NO_EXCLUDE_DESCENDANTS);connect.addView(key);gap(connect,12);
        LinearLayout buttons=row();weighted(buttons,button("Save key",true,()->{credentials.save(key.getText().toString());key.setText("");verified=false;refreshNotice();toast("Key encrypted and saved on this phone. Send a message to verify access.");showTab("Settings");}));weighted(buttons,button("Remove key",false,()->{credentials.remove();key.setText("");verified=false;refreshNotice();toast("Stored credential removed.");showTab("Settings");}));connect.addView(buttons);gap(connect,10);connect.addView(label("The credential is decrypted in this app’s process to authenticate HTTPS calls. Do not share your key. A ChatGPT subscription or app connection does not automatically supply an API key.",11,MUTED));
        LinearLayout models=card(p);models.addView(label("Models",20,TEXT));gap(models,12);models.addView(label("Conversation",12,MUTED));EditText model=edit("Chat model",false);model.setText(prefs.getString("model","gpt-6.1-sol"));models.addView(model);gap(models,12);models.addView(label("Transcription",12,MUTED));EditText transcription=edit("Transcription model",false);transcription.setText(prefs.getString("transcription","gpt-transcribe"));models.addView(transcription);gap(models,14);models.addView(button("Save model names",false,()->{String m=model.getText().toString().trim(),t=transcription.getText().toString().trim();if(!m.matches("[a-zA-Z0-9._-]{1,100}")||!t.matches("[a-zA-Z0-9._-]{1,100}"))throw new IOException("Enter valid model names.");prefs.edit().putString("model",m).putString("transcription",t).apply();verified=false;toast("Model preferences saved. Access is checked when you use them.");}));
        LinearLayout privacy=card(p);privacy.addView(label("Voice & privacy",20,TEXT));gap(privacy,10);privacy.addView(label("Hold Talk to record; release to send that recording to OpenAI for transcription. Review the text before sending a chat message. Temporary recordings are deleted after transcription or cancellation. Backgrounding the app stops recording and interrupts requests. Android’s installed text-to-speech engine reads replies; voice availability and network use depend on that engine. All spoken replies are AI-generated.",13,MUTED));
        LinearLayout vault=card(p);vault.addView(label("Memory you own",20,TEXT));gap(vault,10);vault.addView(label(memory.list().size()+" Markdown notes · "+memory.timezone()+" daily notes.\nRules are loaded every chat turn. Generated indexes and daily logs are protected. Export a vault copy to open in Obsidian Mobile. App-private data is removed when you uninstall; export notes you want to keep.",13,MUTED));gap(vault,14);vault.addView(button("Export Markdown vault",false,()->export(EXPORT_VAULT)));
        LinearLayout source=card(p);source.addView(label("Made to stay open",20,TEXT));gap(source,10);source.addView(label("Native Android code · AGPL-3.0-or-later. Marketing references by Jared Rhodenizer · CC BY-SA 4.0. No warranty. The native touch board replaces the desktop webcam board. This is an independent app, not an official OpenAI or Jared Rhodenizer product.",12,MUTED));gap(source,14);source.addView(button("Export complete source",false,()->export(EXPORT_SOURCE)));gap(source,9);source.addView(button("Attribution & licenses",false,()->readDialog("Attribution & licenses",asset("THIRD_PARTY_NOTICES.md")+"\n\n"+asset("licenses/AGPL-3.0.txt")+"\n\n"+asset("licenses/CC-BY-SA-4.0.txt"))));
    }
    private void readDialog(String title,String text){LinearLayout p=column();pad(p,18,12,18,20);TextView content=label(text,13,TEXT);content.setTextIsSelectable(true);p.addView(content);new AlertDialog.Builder(this).setTitle(title).setView(scroll(p)).setNegativeButton("Close",null).show();}
    private void export(int request){Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);intent.addCategory(Intent.CATEGORY_OPENABLE);intent.setType("application/zip");intent.putExtra(Intent.EXTRA_TITLE,request==EXPORT_VAULT?"JARVIS-Vault-"+memory.today()+".zip":"JARVIS-Android-Source.zip");startActivityForResult(intent,request);}
    private void importNote(){Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT);intent.addCategory(Intent.CATEGORY_OPENABLE);intent.setType("text/*");startActivityForResult(intent,IMPORT_NOTE);}
    @Override protected void onActivityResult(int request,int result,Intent intent){
        super.onActivityResult(request,result,intent);if(result!=RESULT_OK||intent==null||intent.getData()==null)return;Uri uri=intent.getData();
        if(request==IMPORT_NOTE){run(()->{
            String name="Imported note.md";try(Cursor c=getContentResolver().query(uri,new String[]{OpenableColumns.DISPLAY_NAME},null,null,null)){if(c!=null&&c.moveToFirst())name=c.getString(0);}
            name=name.replaceAll("[^\\p{L}\\p{N} ._-]","_");if(!name.endsWith(".md"))name+=".md";
            String contents;try(InputStream in=getContentResolver().openInputStream(uri)){contents=text(in,200000);}editor(null,"Projects/"+name,contents,false,false);
        });return;}
        if(request==EXPORT_VAULT||request==EXPORT_SOURCE){busy(true);worker.execute(()->{Exception failure=null;try(OutputStream out=getContentResolver().openOutputStream(uri,"wt")){if(out==null)throw new IOException("The selected destination could not be opened.");if(request==EXPORT_VAULT)memory.exportZip(out);else try(InputStream in=getAssets().open("source.zip")){byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1)out.write(b,0,n);}}catch(Exception e){failure=e;}Exception error=failure;ui(()->{busy(false);toast(error==null?"Export saved to the location you selected.":safe(error));});});}
    }
    @Override protected void onResume(){super.onResume();paused=false;}
    @Override protected void onStop(){paused=true;if(voice!=null)voice.pause();if(client!=null)client.cancel();super.onStop();}
    @Override protected void onDestroy(){if(client!=null)client.cancel();if(voice!=null)voice.close();worker.shutdownNow();super.onDestroy();}
    @Override public void onRequestPermissionsResult(int request,String[] permissions,int[] grants){super.onRequestPermissionsResult(request,permissions,grants);if(request==70)toast(grants.length>0&&grants[0]==android.content.pm.PackageManager.PERMISSION_GRANTED?"Microphone allowed. Hold Talk to start recording.":"Microphone permission was not granted. You can still type messages.");}
    private void fatal(String message){LinearLayout p=column();pad(p,24,40,24,24);p.setBackgroundColor(BG);p.addView(label("JARVIS",30,TEXT));gap(p,20);p.addView(label(message,15,TEXT));setContentView(p);}
}
