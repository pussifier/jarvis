package com.jarvis.assistant;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import java.io.File;
import java.util.*;

/** Foreground push-to-talk only. Recordings never enter the Markdown vault. */
public final class VoiceController {
    public interface Listener {void state(String value);void recording(File file);void error(String message);}
    private final Activity activity;private final Listener listener;private final Handler handler=new Handler(Looper.getMainLooper());
    private MediaRecorder recorder;private File file;private long started;private TextToSpeech tts;private boolean ttsReady,closed;
    private final Runnable limit=()->stopRecording(false);
    public VoiceController(Activity activity,Listener listener){
        this.activity=activity;this.listener=listener;
        tts=new TextToSpeech(activity,status->{
            if(closed)return;ttsReady=status==TextToSpeech.SUCCESS;
            if(ttsReady){int result=tts.setLanguage(Locale.getDefault());ttsReady=result!=TextToSpeech.LANG_MISSING_DATA&&result!=TextToSpeech.LANG_NOT_SUPPORTED;}
        });
        tts.setOnUtteranceProgressListener(new UtteranceProgressListener(){
            public void onStart(String id){handler.post(()->{if(!closed)listener.state("speaking");});}
            public void onDone(String id){handler.post(()->{if(!closed)listener.state("idle");});}
            public void onError(String id){handler.post(()->{if(!closed){listener.state("idle");listener.error("Android speech playback failed. Check the installed speech engine in phone settings.");}});}
        });
    }
    public boolean recording(){return recorder!=null;}
    public void startRecording(){
        if(closed||recorder!=null)return;
        stopSpeech();
        if(activity.checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){activity.requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},70);listener.error("Allow microphone access, then hold Talk again.");return;}
        try{
            file=new File(activity.getCacheDir(),"jarvis-recording-"+UUID.randomUUID()+".m4a");
            recorder=Build.VERSION.SDK_INT>=31?new MediaRecorder(activity):new MediaRecorder();
            recorder.setAudioSource(MediaRecorder.AudioSource.MIC);recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            recorder.setAudioSamplingRate(44100);recorder.setAudioEncodingBitRate(64000);recorder.setOutputFile(file.getAbsolutePath());
            recorder.setOnErrorListener((r,what,extra)->{stopRecording(true);listener.error("Microphone recording failed. No audio was sent.");});
            recorder.prepare();recorder.start();started=System.currentTimeMillis();listener.state("listening");handler.postDelayed(limit,60000);
        }catch(Exception e){stopRecording(true);listener.error("Could not start the microphone. Check permission and whether another app is recording.");}
    }
    public void stopRecording(boolean discard){
        handler.removeCallbacks(limit);if(recorder==null)return;
        try{recorder.stop();}catch(Exception e){discard=true;}finally{try{recorder.release();}catch(Exception ignored){}recorder=null;}
        File result=file;file=null;listener.state("idle");
        if(discard||System.currentTimeMillis()-started<350||result==null||result.length()==0){if(result!=null)result.delete();return;}
        listener.recording(result);
    }
    public void speak(String text){
        if(closed)return;
        if(!ttsReady){listener.error("Android speech is not ready or has no voice for your device language. Install a voice in phone settings.");return;}
        tts.stop();int max=TextToSpeech.getMaxSpeechInputLength();
        for(int i=0;i<text.length();i+=max){String part=text.substring(i,Math.min(text.length(),i+max));int result=tts.speak(part,TextToSpeech.QUEUE_ADD,null,"jarvis-"+i);if(result==TextToSpeech.ERROR){listener.error("Android speech could not start.");break;}}
    }
    public void stopSpeech(){if(tts!=null)tts.stop();}
    public void pause(){stopRecording(true);stopSpeech();listener.state("idle");}
    public void close(){closed=true;pause();handler.removeCallbacksAndMessages(null);if(tts!=null){tts.shutdown();tts=null;}}
}
