# JARVIS Android: attribution and source

JARVIS Android is an independent native Android application. It is not endorsed by OpenAI, Samsung or Jared Rhodenizer. Native application source is provided under AGPL-3.0-or-later, without warranty. Complete license text is bundled in `assets/licenses/AGPL-3.0.txt`. Choose “Export complete source” in Settings for the full native source ZIP. No Python server, WebView, desktop installer, or browser runtime is bundled.

## Jared Rhodenizer’s marketing references

Copyright 2026 Jared Rhodenizer (@jaredrhod). Source: https://github.com/jaredrhod/ai-marketing-skills . Two complete files are included unchanged: `jareds-takes.md` (Git blob `3870633e5dcf2dd034d3b348fd8b3e9499d1aec2`) and `marketing-content.md` (Git blob `fb34fef7c9fa01d9e7d94a48daa47dba5c409af5`). They retain CC BY-SA 4.0; the complete license is bundled in `assets/licenses/CC-BY-SA-4.0.txt`. Credit the author and share adaptations under the same terms. These opinionated references are data, not executable instructions or action approvals. The other upstream playbooks are not bundled.

## Architectural references

The Markdown memory, indexes, daily notes and context-on-demand approach references https://github.com/jaredrhod/ai-memory-vault . The original user-supplied rules seed the local vault. The prior Python implementation was ported into the native Java memory/action/session design. The native Canvas visualizer and touch/stylus board are new Android code; the `ai-visualizer` and `barehands` HTML/JavaScript engines are not shipped in this APK. The native touch board replaces the desktop webcam gesture board. `backtalk` and `fullstack-agent` are Claude Code references, not Android dependencies; their scripts are not run.

## Android and OpenAI

Android UI, Android Keystore, recording and text-to-speech are platform services. Android’s text-to-speech voice availability and processing location depend on the user’s installed engine. Audio recordings are sent to OpenAI only after the foreground recording is released; AI requests use the user’s personal API account and require internet access. No API key is embedded in the application or exported source. OpenAI contracts follow official Responses streaming and file-transcription documentation. There is no claim that documentation or mock-service tests establish live-account or S24 Ultra device verification.

## Build/test tools

Official Android API 35 platform/build tools and OpenJDK 21 are workspace-only build tools, not APK runtime dependencies. Published tool-package checksums were verified during setup. Native application code uses Android’s built-in `org.json`; the standalone `org.json:json:20240303` artifact is only a JVM test dependency and is not packaged into the APK. Its upstream source and notices are at https://github.com/stleary/JSON-java . The app’s local signing certificate identifies this test build; it is not a Google Play production release.
