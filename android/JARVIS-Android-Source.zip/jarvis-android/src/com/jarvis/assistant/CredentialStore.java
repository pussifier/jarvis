package com.jarvis.assistant;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import javax.crypto.*;
import javax.crypto.spec.GCMParameterSpec;

/** Personal user-entered key only; no shared API credential ships in the APK. */
public final class CredentialStore {
    private static final String ALIAS="jarvis-personal-api-encryption-v1";
    private final SharedPreferences prefs;
    public CredentialStore(Context context){prefs=context.getSharedPreferences("private-credentials",Context.MODE_PRIVATE);}
    private SecretKey key() throws Exception {
        KeyStore store=KeyStore.getInstance("AndroidKeyStore");store.load(null);
        if(!store.containsAlias(ALIAS)){
            KeyGenerator gen=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
            gen.init(new KeyGenParameterSpec.Builder(ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());gen.generateKey();
        }
        return (SecretKey)store.getKey(ALIAS,null);
    }
    public boolean configured(){return prefs.contains("ciphertext")&&prefs.contains("iv");}
    public synchronized void save(String value) throws Exception {
        if(value==null||value.trim().isEmpty())throw new Exception("Enter your personal API key in Settings.");
        if(!value.trim().matches("[A-Za-z0-9._-]{16,1024}"))throw new Exception("The key contains spaces or unsupported characters. Paste only the API key into this field.");
        Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.ENCRYPT_MODE,key());
        byte[] encrypted=cipher.doFinal(value.trim().getBytes(StandardCharsets.UTF_8));
        boolean ok=prefs.edit().putString("ciphertext",Base64.encodeToString(encrypted,Base64.NO_WRAP)).putString("iv",Base64.encodeToString(cipher.getIV(),Base64.NO_WRAP)).commit();
        if(!ok)throw new Exception("Credential storage failed.");
    }
    public synchronized String get() throws Exception {
        if(!configured())throw new Exception("Add your personal OpenAI API key in Settings. Do not put it in chat or notes.");
        try{
            Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,Base64.decode(prefs.getString("iv",""),Base64.NO_WRAP)));
            return new String(cipher.doFinal(Base64.decode(prefs.getString("ciphertext",""),Base64.NO_WRAP)),StandardCharsets.UTF_8);
        }catch(Exception e){throw new Exception("The stored key could not be decrypted. Remove it and enter it again in Settings.");}
    }
    public synchronized void remove() throws Exception {
        if(!prefs.edit().clear().commit())throw new Exception("Credential removal failed.");
        KeyStore store=KeyStore.getInstance("AndroidKeyStore");store.load(null);if(store.containsAlias(ALIAS))store.deleteEntry(ALIAS);
    }
}
