#!/usr/bin/env bash
set -euo pipefail
PROJECT_DIR="$(cd -- "$(dirname -- "$0")/.." && pwd)"
TOOLS_DIR="${JARVIS_ANDROID_TOOLS:-$(dirname "$PROJECT_DIR")/android-tools}"
JDK_DIR="${JARVIS_JDK:-$TOOLS_DIR/jdk/jdk-21.0.2}"
JSON_JAR="${JARVIS_TEST_JSON:-$TOOLS_DIR/json-tests.jar}"
if [[ ! -f "$JSON_JAR" ]]; then echo 'Missing test-only org.json:json:20240303 JAR. Set JARVIS_TEST_JSON to its local path.' >&2; exit 1; fi
cd "$PROJECT_DIR"
mkdir -p build/test-classes
"$JDK_DIR/bin/javac" -encoding UTF-8 -cp "$JSON_JAR" -d build/test-classes src/com/jarvis/assistant/MemoryVault.java src/com/jarvis/assistant/SessionStore.java src/com/jarvis/assistant/ActionStore.java src/com/jarvis/assistant/OpenAiClient.java tests/NativeTests.java
"$JDK_DIR/bin/java" -cp "build/test-classes:$JSON_JAR" com.jarvis.assistant.NativeTests
