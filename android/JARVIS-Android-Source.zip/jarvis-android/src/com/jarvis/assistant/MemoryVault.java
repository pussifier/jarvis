package com.jarvis.assistant;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.regex.Pattern;
import java.util.stream.Stream;
import java.util.zip.*;

/** Durable Markdown memory. SPDX-License-Identifier: AGPL-3.0-or-later. */
public final class MemoryVault {
    public final File root;
    private final ZoneId zone;
    private static final int MAX_BYTES = 200000;
    private static final Pattern SECRET = Pattern.compile("(?i)(sk-[a-z0-9_-]{16,}|Bearer\\s+[a-z0-9_.-]{16,}|(?:api[_ -]?key|password|secret|token)\\s*[:=]\\s*\\S{8,})");

    public MemoryVault(File root, String timezone) throws Exception {
        this.root = root.getCanonicalFile();
        this.zone = ZoneId.of(timezone);
        if (!this.root.isDirectory() && !this.root.mkdirs()) throw new IOException("Cannot create the memory vault.");
    }

    public static String readFile(File file) throws IOException {
        if (file.length() > 2000000) throw new IOException("File exceeds the complete-read limit.");
        return new String(Files.readAllBytes(file.toPath()), StandardCharsets.UTF_8);
    }

    public static void atomicWrite(File file, String text) throws Exception {
        File folder = file.getParentFile();
        if (!folder.isDirectory() && !folder.mkdirs()) throw new IOException("Cannot create a storage folder.");
        File temp = new File(folder, file.getName() + ".tmp");
        byte[] bytes = text.getBytes(StandardCharsets.UTF_8);
        try (FileOutputStream out = new FileOutputStream(temp)) { out.write(bytes); out.getFD().sync(); }
        try { Files.move(temp.toPath(), file.toPath(), StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING); }
        catch (AtomicMoveNotSupportedException e) { Files.move(temp.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING); }
        if (!Arrays.equals(Files.readAllBytes(file.toPath()), bytes)) throw new IOException("Storage read-back verification failed.");
    }

    public synchronized File path(String relative) throws Exception {
        if (relative == null || relative.isEmpty() || relative.length() > 240 || relative.startsWith("/") || relative.contains("\\") || !relative.endsWith(".md"))
            throw new IOException("Choose a relative .md note path.");
        File current = root;
        for (String part : relative.split("/", -1)) {
            if (part.isEmpty() || part.startsWith(".") || !part.matches("[\\p{L}\\p{N} _().-]+")) throw new IOException("Use letters, numbers, spaces, periods, parentheses, hyphens or underscores in note names.");
            current = new File(current, part);
            if (Files.isSymbolicLink(current.toPath())) throw new IOException("Symlinked notes are not supported.");
        }
        File target = current.getCanonicalFile();
        if (!target.toPath().startsWith(root.toPath()) || target.equals(root)) throw new IOException("The note is outside the vault.");
        return target;
    }

    public String today() { return LocalDate.now(zone).toString(); }
    public String timezone() { return zone.getId(); }

    public synchronized void initialize(String rules) throws Exception {
        File file = path("Rules.md");
        if (!file.exists()) atomicWrite(file, rules);
        for (String folder : new String[]{"Projects", "01 - Daily Notes"}) {
            path(folder + "/" + folder + ".md");
            File dir = new File(root, folder);
            if (!dir.exists() && !dir.mkdirs()) throw new IOException("Cannot initialize the vault.");
        }
        File welcome = path("Projects/JARVIS.md");
        if (!welcome.exists()) atomicWrite(welcome, "# JARVIS\n\nA native personal assistant. Your durable knowledge lives in Markdown on this phone.\n\nUse Export vault to make an Obsidian-compatible copy. Conversation transcripts are stored separately.\n");
        indexes(new File(root, "Projects"));
        indexes(new File(root, "01 - Daily Notes"));
    }

    public synchronized String read(String relative) throws Exception {
        File file = path(relative);
        if (file.length() > MAX_BYTES) throw new IOException("This note exceeds 200 KB. It was not partially read.");
        return readFile(file);
    }

    public synchronized String revision(String relative) throws Exception {
        File file = path(relative);
        if (!file.exists()) return null;
        byte[] hash = MessageDigest.getInstance("SHA-256").digest(Files.readAllBytes(file.toPath()));
        StringBuilder out = new StringBuilder();
        for (byte b : hash) out.append(String.format(Locale.ROOT, "%02x", b & 255));
        return out.toString();
    }

    public boolean protectedNote(String relative) {
        File p = new File(relative);
        File parent = p.getParentFile();
        return relative.equals("Rules.md") || relative.equals("VAULT-INDEX.md") || relative.startsWith("01 - Daily Notes/") ||
                (parent != null && p.getName().equals(parent.getName() + ".md"));
    }

    public static void validateContent(String content) throws Exception {
        if (content == null || content.trim().isEmpty() || content.getBytes(StandardCharsets.UTF_8).length > MAX_BYTES)
            throw new IOException("A note needs 1–200,000 bytes of text.");
        if (SECRET.matcher(content).find()) throw new IOException("A credential-like value was detected. Keep credentials in Settings, not notes.");
    }

    private void checkIndexes(File folder) throws Exception {
        while (folder.toPath().startsWith(root.toPath())) {
            String name = folder.equals(root) ? "VAULT-INDEX.md" : folder.getName() + ".md";
            path(root.toPath().relativize(new File(folder, name).toPath()).toString());
            if (folder.equals(root)) break;
            folder = folder.getParentFile();
        }
    }

    public synchronized JSONObject write(String relative, String content, String expected) throws Exception {
        validateContent(content);
        File file = path(relative);
        if (protectedNote(relative)) throw new IOException("Rules, indexes and daily logs are managed notes.");
        if (!Objects.equals(revision(relative), expected)) throw new IOException("The note changed after review. Reload it before saving.");
        checkIndexes(file.getParentFile());
        path("01 - Daily Notes/" + today() + ".md");
        path("01 - Daily Notes/01 - Daily Notes.md");
        atomicWrite(file, content);
        indexes(file.getParentFile());
        log("Updated [[" + relative.substring(0, relative.length() - 3) + "]].");
        return new JSONObject().put("path", relative).put("revision", revision(relative)).put("verified", true);
    }

    public synchronized void log(String message) throws Exception {
        File file = path("01 - Daily Notes/" + today() + ".md");
        String old = file.exists() ? readFile(file) : "# " + today() + "\n";
        String stamp = ZonedDateTime.now(zone).format(DateTimeFormatter.ofPattern("HH:mm:ss"));
        atomicWrite(file, old + "\n- " + stamp + " " + message.replace('\n', ' ') + "\n");
        indexes(file.getParentFile());
    }

    private synchronized void indexes(File folder) throws Exception {
        while (folder.toPath().startsWith(root.toPath())) {
            String name = folder.equals(root) ? "VAULT-INDEX.md" : folder.getName() + ".md";
            File index = path(root.toPath().relativize(new File(folder, name).toPath()).toString());
            File[] files = folder.listFiles();
            if (files == null) throw new IOException("Cannot index a memory folder.");
            Arrays.sort(files, Comparator.comparing(File::getName));
            String marker = "\n<!-- JARVIS generated index -->\n";
            String old = index.exists() ? readFile(index) : "# " + (folder.equals(root) ? "Vault" : folder.getName()) + "\n";
            int split = old.indexOf(marker);
            StringBuilder text = new StringBuilder(split >= 0 ? old.substring(0, split) : old);
            text.append(marker);
            for (File p : files) {
                if (p.getName().startsWith(".") || p.getName().equals(name) || Files.isSymbolicLink(p.toPath())) continue;
                String rel = root.toPath().relativize(p.toPath()).toString();
                if (p.isDirectory()) text.append("- [[").append(rel).append('/').append(p.getName()).append("]]\n");
                else if (p.getName().endsWith(".md")) text.append("- [[").append(rel.substring(0, rel.length() - 3)).append("]]\n");
            }
            atomicWrite(index, text.toString());
            if (folder.equals(root)) break;
            folder = folder.getParentFile();
        }
    }

    public synchronized List<String> list() throws Exception {
        List<String> result = new ArrayList<>();
        try (Stream<Path> paths = Files.walk(root.toPath())) {
            Iterator<Path> it = paths.iterator();
            while (it.hasNext()) {
                Path p = it.next();
                if (!Files.isRegularFile(p) || !p.toString().endsWith(".md")) continue;
                String rel = root.toPath().relativize(p).toString();
                try { path(rel); result.add(rel); } catch (Exception ignored) { }
            }
        }
        Collections.sort(result);
        return result;
    }

    public synchronized JSONArray search(String query) throws Exception {
        String[] terms = query.toLowerCase(Locale.ROOT).split("\\W+");
        List<JSONObject> results = new ArrayList<>();
        for (String rel : list()) {
            String text;
            try { text = read(rel); } catch (IOException e) { continue; }
            String lower = text.toLowerCase(Locale.ROOT);
            int score = 0;
            for (String term : terms) {
                if (term.length() < 2) continue;
                if (lower.contains(term)) score++;
                if (rel.toLowerCase(Locale.ROOT).contains(term)) score += 4;
            }
            if (score > 0) results.add(new JSONObject().put("path", rel).put("score", score));
        }
        results.sort((a,b) -> Integer.compare(b.optInt("score"), a.optInt("score")));
        JSONArray out = new JSONArray();
        for (int i = 0; i < Math.min(results.size(), 20); i++) out.put(results.get(i));
        return out;
    }

    public synchronized JSONArray context(String message, String selected) throws Exception {
        LinkedHashSet<String> paths = new LinkedHashSet<>();
        if (selected != null && !selected.isEmpty()) paths.add(selected);
        JSONArray matches = search(message);
        for (int i = 0; i < matches.length() && paths.size() < 4; i++) {
            String p = matches.getJSONObject(i).getString("path");
            if (!p.equals("Rules.md") && !p.equals("VAULT-INDEX.md")) paths.add(p);
        }
        JSONArray out = new JSONArray(); int total = 0;
        for (String p : paths) { String text = read(p); total += text.length(); out.put(new JSONObject().put("path", p).put("content", text)); }
        if (total > 80000) throw new IOException("The selected full notes exceed the context budget. Choose a smaller note set.");
        return out;
    }

    public synchronized void exportZip(OutputStream destination) throws Exception {
        try (ZipOutputStream zip = new ZipOutputStream(destination)) {
            for (String rel : list()) {
                zip.putNextEntry(new ZipEntry("JARVIS Vault/" + rel));
                zip.write(read(rel).getBytes(StandardCharsets.UTF_8));
                zip.closeEntry();
            }
        }
    }
}
