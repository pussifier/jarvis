package com.jarvis.assistant;

import org.json.*;
import com.sun.net.httpserver.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.atomic.*;

/** Runs the actual native core on the JVM, without an Android UI or API credits. */
public final class NativeTests {
    interface Checked {void run() throws Exception;}
    static int passed=0;
    static void check(boolean value,String reason){if(!value)throw new AssertionError(reason);}
    static void rejects(Checked task,String reason) throws Exception {boolean rejected=false;try{task.run();}catch(Exception e){rejected=true;}check(rejected,reason);}
    static void test(String name,Checked task) throws Exception {task.run();passed++;System.out.println("PASS "+name);}
    static MemoryVault memory(File root) throws Exception {MemoryVault m=new MemoryVault(root,"Asia/Manila");m.initialize("# Rules\nEvidence only. Ask before effects.");return m;}
    static final OpenAiClient.Listener QUIET=new OpenAiClient.Listener(){public void onText(String d){}public void onSources(List<String> p){}public void onAction(){}};
    static String read(InputStream in) throws Exception {ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[4096];int n;while((n=in.read(b))!=-1)out.write(b,0,n);return new String(out.toByteArray(),StandardCharsets.UTF_8);}
    static void event(OutputStream out,JSONObject event) throws Exception {out.write(("data: "+event.toString()+"\n\n").getBytes(StandardCharsets.UTF_8));out.flush();}

    public static void main(String[] args) throws Exception {
        Path temp=Files.createTempDirectory("jarvis-native-tests-");
        try{
            test("memory persistence, read-back verification and nested indexes",()->{
                MemoryVault m=memory(temp.resolve("persist").toFile());String text="# Decision\nA durable decision.\n";
                JSONObject result=m.write("Projects/Business/Decision.md",text,null);
                check(result.getBoolean("verified"),"write was not verified");
                MemoryVault restored=memory(m.root);check(restored.read("Projects/Business/Decision.md").equals(text),"content changed after restart");
                check(restored.read("Projects/Business/Business.md").contains("Projects/Business/Decision"),"child index drift");
                check(restored.read("Projects/Projects.md").contains("Projects/Business/Business"),"parent index drift");
                check(restored.read("01 - Daily Notes/"+m.today()+".md").contains("Updated [[Projects/Business/Decision]]"),"daily checkpoint missing");
            });
            test("existing operator rules survive startup",()->{
                MemoryVault m=memory(temp.resolve("rules").toFile());String old=m.read("Rules.md");m.initialize("# Different default");check(m.read("Rules.md").equals(old),"startup replaced rules");
            });
            test("revision conflicts never overwrite a newer edit",()->{
                MemoryVault m=memory(temp.resolve("revision").toFile());m.write("Projects/One.md","# First",null);String revision=m.revision("Projects/One.md");m.write("Projects/One.md","# Second",revision);
                rejects(()->m.write("Projects/One.md","# Stale",revision),"stale write accepted");check(m.read("Projects/One.md").equals("# Second"),"newer text lost");
            });
            test("traversal and non-Markdown paths are rejected",()->{
                MemoryVault m=memory(temp.resolve("paths").toFile());
                for(String path:new String[]{"../outside.md","/tmp/outside.md","Projects/../../outside.md",".hidden.md","Projects\\outside.md","code.java","Projects//empty.md","Projects/Broken\nindex.md","Projects/Injected]]index.md"})rejects(()->m.write(path,"# No",null),"unsafe path accepted: "+path);
            });
            test("symlink folders and indexes cannot escape or cause a partial write",()->{
                MemoryVault m=memory(temp.resolve("links").toFile());Path outside=Files.createDirectory(temp.resolve("outside"));Files.createSymbolicLink(new File(m.root,"Linked").toPath(),outside);
                rejects(()->m.write("Linked/Escape.md","# No",null),"symlink escape accepted");check(!Files.exists(outside.resolve("Escape.md")),"wrote outside vault");
                Path index=new File(m.root,"Projects/Projects.md").toPath();Files.delete(index);Path secret=outside.resolve("index.md");Files.write(secret,"untouched".getBytes(StandardCharsets.UTF_8));Files.createSymbolicLink(index,secret);
                rejects(()->m.write("Projects/Partial.md","# No partial write",null),"symlink index accepted");check(!new File(m.root,"Projects/Partial.md").exists(),"partial write occurred");check(read(Files.newInputStream(secret)).equals("untouched"),"external index overwritten");
            });
            test("rules, indexes, and daily notes are protected",()->{
                MemoryVault m=memory(temp.resolve("protected").toFile());for(String path:new String[]{"Rules.md","VAULT-INDEX.md","Projects/Projects.md","01 - Daily Notes/Any.md"})rejects(()->m.write(path,"# Replace",m.revision(path)),"managed note replaced");
            });
            test("daily logs remain append-only",()->{
                MemoryVault m=memory(temp.resolve("daily").toFile());m.log("First checkpoint");String before=m.read("01 - Daily Notes/"+m.today()+".md");m.log("Second checkpoint");String after=m.read("01 - Daily Notes/"+m.today()+".md");check(after.startsWith(before),"daily log rewritten");check(after.contains("Second checkpoint"),"second checkpoint missing");
            });
            test("credential-like values cannot enter curated memory",()->{
                MemoryVault m=memory(temp.resolve("credentials").toFile());String fake="sk-"+"abcdefghijklmnopqrstuvwx";
                rejects(()->m.write("Projects/Credential.md",fake,null),"credential-like note accepted");check(!new File(m.root,"Projects/Credential.md").exists(),"credential-like value written");
            });
            test("full note context is complete; oversized context is explicit",()->{
                MemoryVault m=memory(temp.resolve("context").toFile());String full="# Mercury\n"+String.join("",Collections.nCopies(300,"Full context.\n"));m.write("Projects/Mercury.md",full,null);
                JSONArray context=m.context("Mercury","Projects/Mercury.md");check(context.getJSONObject(0).getString("content").equals(full),"context silently sampled");
                String large="# Large\n"+String.join("",Collections.nCopies(81000,"x"));m.write("Projects/Large.md",large,null);rejects(()->m.context("Large","Projects/Large.md"),"oversize context silently trimmed");
            });
            test("a model proposal cannot write before approval",()->{
                MemoryVault m=memory(temp.resolve("proposal").toFile());ActionStore a=new ActionStore(new File(m.root.getParentFile(),"actions.json"),m);JSONObject p=a.propose("s","save_memory",new JSONObject().put("path","Projects/Review.md").put("content","# Review\nA fact."));
                check(!new File(m.root,"Projects/Review.md").exists(),"proposal wrote a note");JSONObject result=a.decide("s",p.getString("id"),true);check(result.getString("status").equals("completed"),"approved effect failed");check(m.read("Projects/Review.md").contains("A fact"),"approved content missing");rejects(()->a.decide("s",p.getString("id"),true),"effect replayed");
            });
            test("wrong session and rejection cannot authorize an effect",()->{
                MemoryVault m=memory(temp.resolve("deny").toFile());ActionStore a=new ActionStore(new File(m.root.getParentFile(),"actions.json"),m);JSONObject p=a.propose("s","save_memory",new JSONObject().put("path","Projects/Denied.md").put("content","# Denied"));
                rejects(()->a.decide("other",p.getString("id"),true),"wrong session approved");check(a.decide("s",p.getString("id"),false).getString("status").equals("rejected"),"rejection not recorded");check(!new File(m.root,"Projects/Denied.md").exists(),"rejected action wrote data");
            });
            test("stale action review preserves intervening human changes",()->{
                MemoryVault m=memory(temp.resolve("stale-action").toFile());ActionStore a=new ActionStore(new File(m.root.getParentFile(),"actions.json"),m);JSONObject p=a.propose("s","save_memory",new JSONObject().put("path","Projects/New.md").put("content","# Proposed"));m.write("Projects/New.md","# Human",null);
                check(a.decide("s",p.getString("id"),true).getString("status").equals("failed"),"stale proposal completed");check(m.read("Projects/New.md").equals("# Human"),"human change overwritten");
            });
            test("pending proposals survive restart; interrupted effects never replay",()->{
                MemoryVault m=memory(temp.resolve("restart-action").toFile());File path=new File(m.root.getParentFile(),"actions.json");ActionStore a=new ActionStore(path,m);JSONObject p=a.propose("s","save_memory",new JSONObject().put("path","Projects/Restart.md").put("content","# Restart"));
                ActionStore reopened=new ActionStore(path,m);check(reopened.pending("s")==1,"pending proposal lost");
                JSONArray json=new JSONArray(MemoryVault.readFile(path));json.getJSONObject(0).put("status","executing");MemoryVault.atomicWrite(path,json.toString());ActionStore interrupted=new ActionStore(path,m);
                check(interrupted.list("s").getJSONObject(0).getString("status").equals("needs_review"),"interrupted effect was replayable");check(!new File(m.root,"Projects/Restart.md").exists(),"interrupted effect replayed");
            });
            test("model cannot replace rules or call arbitrary tools",()->{
                MemoryVault m=memory(temp.resolve("allowlist").toFile());ActionStore a=new ActionStore(new File(m.root.getParentFile(),"actions.json"),m);
                rejects(()->a.propose("s","save_memory",new JSONObject().put("path","Rules.md").put("content","# Different rules")),"model replaced rules");rejects(()->a.propose("s","shell",new JSONObject()),"arbitrary tool accepted");
            });
            test("approved board cards persist without changing notes",()->{
                MemoryVault m=memory(temp.resolve("board").toFile());File path=new File(m.root.getParentFile(),"actions.json");ActionStore a=new ActionStore(path,m);JSONObject p=a.propose("s","present_board",new JSONObject().put("title","The plan").put("body","A native card."));check(a.boardCards().length()==0,"unapproved card visible");a.decide("s",p.getString("id"),true);check(new ActionStore(path,m).boardCards().getJSONObject(0).getString("title").equals("The plan"),"board card lost");
            });
            test("session data survives restart and enforces session locking",()->{
                File folder=temp.resolve("sessions").toFile();SessionStore s=new SessionStore(folder);JSONObject session=s.create();session.getJSONArray("messages").put(new JSONObject().put("role","user").put("content","A unicode message: café."));s.save(session);String id=session.getString("id");
                check(new SessionStore(folder).get(id).getJSONArray("messages").getJSONObject(0).getString("content").endsWith("café."),"Unicode transcript changed");s.acquire(id);rejects(()->s.acquire(id),"concurrent turn accepted");s.release(id);s.acquire(id);s.release(id);rejects(()->s.get("../bad"),"session traversal accepted");
            });
            test("oversize session writes preserve readable saved history",()->{
                SessionStore store=new SessionStore(temp.resolve("full-session").toFile());JSONObject session=store.create();String id=session.getString("id");
                session.getJSONArray("messages").put(new JSONObject().put("role","user").put("content",String.join("",Collections.nCopies(1800001,"x"))));
                rejects(()->store.save(session),"oversize session was written");check(store.get(id).getJSONArray("messages").length()==0,"saved session was made unreadable");
            });

            HttpServer server=HttpServer.create(new InetSocketAddress("127.0.0.1",0),0);AtomicInteger mode=new AtomicInteger();AtomicReference<JSONObject> sent=new AtomicReference<>();AtomicReference<String> multipart=new AtomicReference<>();
            server.createContext("/v1/responses",exchange->{
                try{
                    JSONObject request=new JSONObject(read(exchange.getRequestBody()));sent.set(request);
                    if(mode.get()==1){byte[] error="private provider detail".getBytes(StandardCharsets.UTF_8);exchange.sendResponseHeaders(401,error.length);exchange.getResponseBody().write(error);exchange.close();return;}
                    exchange.getResponseHeaders().set("Content-Type","text/event-stream");exchange.sendResponseHeaders(200,0);OutputStream out=exchange.getResponseBody();
                    if(mode.get()==2){event(out,new JSONObject().put("type","response.output_text.delta").put("delta","An incomplete native reply"));exchange.close();return;}
                    if(mode.get()==3){out.write("data: {\"type\":\ndata: \"response.output_text.delta\",\"delta\":\"Multiline event\"}\n\n".getBytes(StandardCharsets.UTF_8));event(out,new JSONObject().put("type","response.completed").put("response",new JSONObject().put("output",new JSONArray())));exchange.close();return;}
                    boolean continuation=false;JSONArray input=request.getJSONArray("input");for(int i=0;i<input.length();i++)if(input.getJSONObject(i).optString("type").equals("function_call_output"))continuation=true;
                    if(!continuation){JSONObject call=new JSONObject().put("type","function_call").put("call_id","call_1").put("name","save_memory").put("arguments",new JSONObject().put("path","Projects/Network.md").put("content","# Native memory\nApprove this first.").toString());event(out,new JSONObject().put("type","response.completed").put("response",new JSONObject().put("output",new JSONArray().put(call))));}
                    else{event(out,new JSONObject().put("type","response.output_text.delta").put("delta","Your memory update is proposed."));event(out,new JSONObject().put("type","response.completed").put("response",new JSONObject().put("output",new JSONArray())));}
                    exchange.close();
                }catch(Exception e){exchange.close();}
            });
            server.createContext("/v1/audio/transcriptions",exchange->{try{multipart.set(read(exchange.getRequestBody()));byte[] body=new JSONObject().put("text","A transcribed native sentence.").toString().getBytes(StandardCharsets.UTF_8);exchange.sendResponseHeaders(200,body.length);exchange.getResponseBody().write(body);}catch(Exception ignored){}finally{exchange.close();}});
            server.start();String base="http://127.0.0.1:"+server.getAddress().getPort()+"/v1";
            try{
                test("native Responses streaming tools are proposed, not executed",()->{
                    mode.set(0);MemoryVault m=memory(temp.resolve("network").toFile());SessionStore s=new SessionStore(new File(m.root.getParentFile(),"sessions"));JSONObject session=s.create();String id=session.getString("id");ActionStore a=new ActionStore(new File(m.root.getParentFile(),"actions.json"),m);StringBuilder text=new StringBuilder();
                    new OpenAiClient(base).reply("fixture-only","fixture-model","Remember a fact",id,s,m,a,null,new JSONArray(),new OpenAiClient.Listener(){public void onText(String d){text.append(d);}public void onSources(List<String> p){}public void onAction(){}});
                    check(text.toString().equals("Your memory update is proposed."),"stream text was lost");check(!new File(m.root,"Projects/Network.md").exists(),"network tool bypassed human approval");check(a.pending(id)==1,"tool proposal not persisted");check(s.get(id).getJSONArray("messages").length()==2,"completed transcript not persisted");check(!sent.get().getBoolean("store"),"provider storage enabled");check(sent.get().getString("instructions").contains("Ask before effects"),"rules missing from request");
                });
                test("upstream HTTP errors expose no provider body or credential",()->{
                    mode.set(1);try{new OpenAiClient(base).response("fixture-only","model","instructions",new JSONArray(),QUIET);throw new AssertionError("401 accepted");}catch(IOException e){check(e.getMessage().contains("401"),"HTTP status missing");check(!e.getMessage().contains("private provider detail")&&!e.getMessage().contains("fixture-only"),"sensitive upstream details leaked");}
                });
                test("interrupted streams persist partial replies and release session lock",()->{
                    mode.set(2);MemoryVault m=memory(temp.resolve("partial").toFile());SessionStore s=new SessionStore(new File(m.root.getParentFile(),"sessions"));JSONObject session=s.create();String id=session.getString("id");ActionStore a=new ActionStore(new File(m.root.getParentFile(),"actions.json"),m);
                    rejects(()->new OpenAiClient(base).reply("fixture-only","model","Question",id,s,m,a,null,new JSONArray(),QUIET),"incomplete stream accepted");JSONArray messages=s.get(id).getJSONArray("messages");check(messages.length()==2&&messages.getJSONObject(1).getString("content").contains("not complete"),"partial reply lost");s.acquire(id);s.release(id);
                });
                test("multiline SSE events are parsed completely",()->{
                    mode.set(3);StringBuilder out=new StringBuilder();new OpenAiClient(base).response("fixture-only","model","",new JSONArray(),new OpenAiClient.Listener(){public void onText(String d){out.append(d);}public void onSources(List<String> p){}public void onAction(){}});check(out.toString().equals("Multiline event"),"multiline SSE lost");
                });
                test("cancelled turns cannot start requests or retain session locks",()->{
                    MemoryVault m=memory(temp.resolve("cancel").toFile());SessionStore s=new SessionStore(new File(m.root.getParentFile(),"sessions"));JSONObject session=s.create();String id=session.getString("id");ActionStore a=new ActionStore(new File(m.root.getParentFile(),"actions.json"),m);OpenAiClient client=new OpenAiClient(base);client.cancel();rejects(()->client.reply("fixture-only","model","Q",id,s,m,a,null,new JSONArray(),QUIET),"cancelled turn proceeded");check(s.get(id).getJSONArray("messages").length()==0,"cancelled request wrote a message");s.acquire(id);s.release(id);
                });
                test("native recording upload is multipart and transcript is returned",()->{
                    File audio=temp.resolve("recording.m4a").toFile();Files.write(audio.toPath(),"fixture audio bytes".getBytes(StandardCharsets.UTF_8));String result=new OpenAiClient(base).transcribe("fixture-only","gpt-transcribe",audio);check(result.equals("A transcribed native sentence."),"transcript lost");check(multipart.get().contains("filename=\"recording.m4a\"")&&multipart.get().contains("gpt-transcribe")&&multipart.get().contains("audio/mp4"),"native audio form is invalid");
                });
                test("non-HTTPS remote API endpoints are rejected",()->rejects(()->new OpenAiClient("http://example.com/v1"),"insecure remote endpoint accepted"));
                test("invalid credential characters are rejected without revealing the value",()->{
                    String malformed="fixture\r\nheader-value";
                    try{new OpenAiClient(base).response(malformed,"model","",new JSONArray(),QUIET);throw new AssertionError("header injection accepted");}
                    catch(IOException e){check(!e.getMessage().contains("fixture")&&!e.getMessage().contains("header-value"),"credential was exposed in error");}
                });
            }finally{server.stop(0);}
            System.out.println("RESULT: "+passed+" native core tests passed.");
        }finally{
            try(java.util.stream.Stream<Path> paths=Files.walk(temp)){paths.sorted(Comparator.reverseOrder()).forEach(p->{try{Files.deleteIfExists(p);}catch(IOException ignored){}});}
        }
    }
}
