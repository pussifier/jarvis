package com.jarvis.assistant;

import org.json.*;
import java.io.*;
import java.util.*;

/** Conversations stay outside the curated Markdown vault. */
public final class SessionStore {
    private final File root;
    private final Set<String> busy = new HashSet<>();
    public SessionStore(File root) throws Exception {
        this.root = root;
        if (!root.isDirectory() && !root.mkdirs()) throw new IOException("Cannot create conversation storage.");
    }
    private File path(String id) throws Exception {
        if (id == null || !id.matches("[a-f0-9]{32}")) throw new IOException("Invalid conversation ID.");
        return new File(root, id + ".json");
    }
    public synchronized JSONObject create() throws Exception {
        JSONObject s = new JSONObject().put("id", UUID.randomUUID().toString().replace("-", "")).put("title", "New conversation").put("messages", new JSONArray());
        save(s); return s;
    }
    public synchronized JSONObject get(String id) throws Exception { return new JSONObject(MemoryVault.readFile(path(id))); }
    public synchronized void save(JSONObject session) throws Exception {
        session.put("updated", System.currentTimeMillis());
        String text=session.toString(2);
        if(text.getBytes(java.nio.charset.StandardCharsets.UTF_8).length>1800000)throw new IOException("Conversation storage limit reached. Create a new conversation; existing history is preserved.");
        MemoryVault.atomicWrite(path(session.getString("id")), text);
    }
    public synchronized List<JSONObject> list() throws Exception {
        List<JSONObject> out = new ArrayList<>();
        File[] files = root.listFiles();
        if (files == null) throw new IOException("Cannot read conversations.");
        for (File file : files) if (file.getName().matches("[a-f0-9]{32}\\.json")) out.add(new JSONObject(MemoryVault.readFile(file)));
        out.sort((a,b) -> Long.compare(b.optLong("updated"), a.optLong("updated")));
        return out;
    }
    public synchronized void acquire(String id) throws Exception {
        path(id);
        if (!busy.add(id)) throw new IOException("A reply is already running in this conversation.");
    }
    public synchronized void release(String id) { busy.remove(id); }
}
