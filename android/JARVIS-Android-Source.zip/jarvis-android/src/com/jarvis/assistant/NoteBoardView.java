package com.jarvis.assistant;

import android.content.Context;
import android.graphics.*;
import android.view.*;
import java.util.*;

/** Native touch/stylus board. Drag cards; pinch to scale; tap to read. */
public final class NoteBoardView extends View {
    public interface Open {void note(String path,String title,String body);}
    public static final class Card {
        public final String path,title,body;float x,y,scale=1;boolean positioned;
        public Card(String path,String title,String body){this.path=path;this.title=title;this.body=body;}
    }
    private final Paint paint=new Paint(3);private final List<Card> cards=new ArrayList<>();private final Open open;
    private final ScaleGestureDetector scaling;private Card held;private float lastX,lastY,startX,startY,panX=0,panY=0;private boolean moved;private long down;
    private final float density;
    public NoteBoardView(Context context,List<Card> initial,Open callback){
        super(context);density=getResources().getDisplayMetrics().density;cards.addAll(initial);open=callback;
        setContentDescription("Notes board. Drag cards with touch or S Pen. Pinch to scale; tap to read. Use Memory for an accessible note list.");
        scaling=new ScaleGestureDetector(context,new ScaleGestureDetector.SimpleOnScaleGestureListener(){@Override public boolean onScale(ScaleGestureDetector d){if(held!=null){held.scale=Math.max(.55f,Math.min(2f,held.scale*d.getScaleFactor()));moved=true;invalidate();}return true;}});
    }
    private RectF rect(Card c){return new RectF(c.x,c.y,c.x+230*density*c.scale,c.y+140*density*c.scale);}
    @Override protected void onDraw(Canvas c){
        super.onDraw(c);c.drawColor(Color.rgb(9,15,24));paint.setColor(Color.rgb(26,43,54));
        for(int x=16;x<getWidth();x+=24*density)for(int y=16;y<getHeight();y+=24*density)c.drawCircle(x,y,1*density,paint);
        c.save();c.translate(panX,panY);
        for(int i=0;i<cards.size();i++){
            Card card=cards.get(i);if(!card.positioned){card.x=18*density+(i%2)*28*density;card.y=(22+i*78)*density;card.positioned=true;}
            RectF r=rect(card);paint.setStyle(Paint.Style.FILL);paint.setColor(Color.rgb(20,43,47));c.drawRoundRect(r,12*density,12*density,paint);paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(density);paint.setColor(card==held?Color.rgb(156,239,217):Color.rgb(56,106,102));c.drawRoundRect(r,12*density,12*density,paint);paint.setStyle(Paint.Style.FILL);
            c.save();c.clipRect(r);paint.setTextSize(14*density*card.scale);paint.setTypeface(Typeface.create("sans-serif-medium",0));paint.setColor(Color.rgb(193,237,225));paint.setTextAlign(Paint.Align.LEFT);c.drawText(card.title,r.left+15*density,r.top+28*density*card.scale,paint);
            paint.setTypeface(Typeface.create("sans-serif",0));paint.setTextSize(11*density*card.scale);paint.setColor(Color.rgb(148,180,181));
            String preview=card.body.replaceAll("\\s+"," ");int width=Math.max(12,(int)((r.width()-30*density)/(6*density*card.scale)));
            for(int row=0;row<3&&row*width<preview.length();row++)c.drawText(preview.substring(row*width,Math.min(preview.length(),(row+1)*width)),r.left+15*density,r.top+(53+row*19)*density*card.scale,paint);
            c.restore();
        }
        c.restore();
    }
    @Override public boolean onTouchEvent(MotionEvent event){
        scaling.onTouchEvent(event);float x=event.getX(),y=event.getY();
        switch(event.getActionMasked()){
            case MotionEvent.ACTION_DOWN:
                held=null;for(int i=cards.size()-1;i>=0;i--)if(rect(cards.get(i)).contains(x-panX,y-panY)){held=cards.remove(i);cards.add(held);break;}
                startX=lastX=x;startY=lastY=y;down=System.currentTimeMillis();moved=false;getParent().requestDisallowInterceptTouchEvent(true);invalidate();return true;
            case MotionEvent.ACTION_MOVE:
                if(!scaling.isInProgress()){if(held!=null){held.x+=x-lastX;held.y+=y-lastY;}else{panX+=x-lastX;panY+=y-lastY;}if(Math.hypot(x-startX,y-startY)>10*density)moved=true;invalidate();}lastX=x;lastY=y;return true;
            case MotionEvent.ACTION_UP:
                if(held!=null&&!moved&&System.currentTimeMillis()-down<500){performClick();open.note(held.path,held.title,held.body);}held=null;getParent().requestDisallowInterceptTouchEvent(false);invalidate();return true;
            case MotionEvent.ACTION_CANCEL:held=null;getParent().requestDisallowInterceptTouchEvent(false);invalidate();return true;
            default:return true;
        }
    }
    @Override public boolean performClick(){super.performClick();return true;}
}
