package com.jarvis.assistant;

import org.json.*;
import java.io.*;
import java.util.*;

/** The model can propose an effect; only the native review control decides it. */
public final class ActionStore {
    private final File file;
    private final MemoryVault memory;
    private final JSONArray items;
    public ActionStore(File file, MemoryVault memory) throws Exception {
        this.file = file; this.memory = memory;
        items = file.exists() ? new JSONArray(MemoryVault.readFile(file)) : new JSONArray();
        for (int i=0; i<items.length(); i++) {
            JSONObject a=items.getJSONObject(i);
            if (a.optString("status").equals("executing")) a.put("status","needs_review").put("result","Interrupted during execution. Inspect the note before proposing again.");
        }
        persist();
    }
    private void persist() throws Exception { MemoryVault.atomicWrite(file,items.toString(2)); }
    public synchronized JSONArray list(String session) throws Exception {
        JSONArray out=new JSONArray();
        for(int i=0;i<items.length();i++) if(items.getJSONObject(i).getString("session_id").equals(session)) out.put(new JSONObject(items.getJSONObject(i).toString()));
        return out;
    }
    public synchronized int pending(String session) throws Exception {
        int count=0; JSONArray list=list(session);
        for(int i=0;i<list.length();i++)if(list.getJSONObject(i).optString("status").equals("pending"))count++;
        return count;
    }
    public synchronized JSONObject propose(String session,String kind,JSONObject raw) throws Exception {
        if(!kind.equals("save_memory")&&!kind.equals("present_board"))throw new IOException("This action is not allowed.");
        JSONObject args=new JSONObject();
        if(kind.equals("save_memory")){
            String path=raw.getString("path"),content=raw.getString("content");
            memory.path(path);MemoryVault.validateContent(content);
            if(memory.protectedNote(path))throw new IOException("The model cannot replace rules, indexes or daily logs.");
            String rev=memory.revision(path);
            args.put("path",path).put("content",content).put("expected_revision",rev==null?JSONObject.NULL:rev);
            args.put("before",rev==null?"":memory.read(path));
        }else{
            String title=raw.getString("title"),body=raw.getString("body");
            if(title.isEmpty()||title.length()>160||body.length()>12000)throw new IOException("Board card is too large.");
            MemoryVault.validateContent(body);
            args.put("title",title).put("body",body);
        }
        JSONObject a=new JSONObject().put("id",UUID.randomUUID().toString().replace("-","")).put("session_id",session).put("kind",kind).put("args",args).put("status","pending").put("created",System.currentTimeMillis());
        items.put(a);persist();memory.log("Proposed action "+a.getString("id")+"; review required.");return new JSONObject(a.toString());
    }
    public synchronized JSONObject decide(String session,String id,boolean approve) throws Exception {
        JSONObject a=null;
        for(int i=0;i<items.length();i++){JSONObject x=items.getJSONObject(i);if(x.getString("id").equals(id)&&x.getString("session_id").equals(session)){a=x;break;}}
        if(a==null||!a.getString("status").equals("pending"))throw new IOException("This proposal is missing or already decided.");
        if(!approve){a.put("status","rejected");persist();memory.log("Rejected action "+id+"; no effect executed.");return new JSONObject(a.toString());}
        if(System.currentTimeMillis()-a.getLong("created")>86400000){a.put("status","expired");persist();throw new IOException("This proposal expired. Ask for a fresh proposal.");}
        a.put("status","executing");persist();
        try{
            JSONObject args=a.getJSONObject("args");
            if(a.getString("kind").equals("save_memory")) a.put("result",memory.write(args.getString("path"),args.getString("content"),args.isNull("expected_revision")?null:args.getString("expected_revision")));
            else a.put("result","Board card saved locally. Open Board to view it.");
            a.put("status","completed");
        }catch(Exception e){a.put("status","failed").put("result",e.getMessage()==null?"Action failed.":e.getMessage());}
        persist();memory.log("Action "+id+": "+a.getString("status")+".");return new JSONObject(a.toString());
    }
    public synchronized JSONArray boardCards() throws Exception {
        JSONArray out=new JSONArray();
        for(int i=0;i<items.length();i++){JSONObject a=items.getJSONObject(i);if(a.optString("kind").equals("present_board")&&a.optString("status").equals("completed"))out.put(new JSONObject(a.getJSONObject("args").toString()).put("id",a.getString("id")));}
        return out;
    }
}
